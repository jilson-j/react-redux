import React from "react";
import { Router, Route } from "react-router-dom";
import history from "../helpers/history";
import Home from "../app/module/Home/Home";
export default function navigation() {
  return (
    <Router history={history}>
      <div>
        <Route exact path="/" component={Home} />
      </div>
    </Router>
  );

}
