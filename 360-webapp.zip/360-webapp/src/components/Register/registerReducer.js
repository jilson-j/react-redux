import { userConstants } from '../../constants/user.constants';
const initialState = {
    registerUser: {}
  }
  export function registeration(state = initialState, action) {
    switch (action.type) {
      case userConstants.REGISTER_REQUEST:
        return { ...state, registerUser: action.payload }
      case userConstants.REGISTER_SUCCESS:
        return { ...state, registerUser: action.payload }
      case userConstants.REGISTER_FAILURE:
      return { ...state, registerUser: action.payload }
      default:
        return state
    }
  }