import { userConstants } from "../../constants/user.constants";
import { userService } from "../../services/user.service";
//import history from "../../helpers/history";
export const registerActions = {
     register
  };
function register (userData){
    return dispatch => {
          dispatch(registerRequest({}))
         userService.register(userData).then(
            register_data=>{
                    dispatch(registerUser(register_data))
            },
            error=>{
               var data = {
                   status:0,
                   message:error
               }
                dispatch(registerError(data))
            }
         )
    }
}
const registerRequest = userObj => ({
    type: userConstants.REGISTER_REQUEST,
    payload: userObj
  });
  
export const registerUser = userObj => ({
    type: userConstants.REGISTER_SUCCESS,
    payload: userObj
  });
  
  const registerError = userObj => ({
    type: userConstants.REGISTER_FAILURE,
    payload: userObj
  });