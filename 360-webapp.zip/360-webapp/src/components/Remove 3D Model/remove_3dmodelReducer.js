import { userConstants } from '../../constants/user.constants';
const initialState = {
    removemodelData:{}
 }
 export function removeModel(state = initialState, action) {
    switch (action.type) {
        case userConstants.REMOVE_360ASSETS_REQUEST:
          return { ...state, removemodelData:action.payload}
        case userConstants.REMOVE_360ASSETS_SUCCESS:
          return { ...state, removemodelData:action.payload}
        case userConstants.REMOVE_360ASSETS_FAILURE:
          return { ...state, removemodelData:action.payload}
        default:
          return state
      }
  }