import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const remove_iplus360Action = {
    delete_iplus360
};
function delete_iplus360(userData){
    return dispatch =>{
        dispatch(removemodelRequest({}))
        userService.delete_iplus360_assets(userData).then(
            removemodelres =>{
                dispatch(removemodelResponse(removemodelres));
            },
            error =>{
                dispatch(removemodelError(error))
            }
         )
      }
    }
    const removemodelRequest = userObj =>({
        type: userConstants.REMOVE_360ASSETS_REQUEST,
        payload: userObj
    })
    export const removemodelResponse = userObj =>({
        type: userConstants.REMOVE_360ASSETS_SUCCESS,
        payload: userObj
    })
    const removemodelError = userObj =>({
        type: userConstants.REMOVE_360ASSETS_FAILURE,
        payload: userObj
    })