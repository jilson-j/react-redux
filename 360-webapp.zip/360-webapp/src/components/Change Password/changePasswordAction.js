import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const ChangePasswordActions = {
    change_password
};
function change_password(userData){
    return dispatch =>{
        dispatch(changepasswordRequest({}))
        userService.changePassword(userData).then(
            changePassword_data =>{
                dispatch(changepasswordResponse(changePassword_data));
            },
            error =>{
                dispatch(changepasswordError(error))
            }
         )
      }
    }
    const changepasswordRequest = userObj =>({
        type: userConstants.CHANGE_PASSWORD_REQUEST,
        payload: userObj
    })
    export const changepasswordResponse = userObj =>({
        type: userConstants.CHANGE_PASSWORD_SUCCESS,
        payload: userObj
    })
    const changepasswordError = userObj =>({
        type: userConstants.CHANGE_PASSWORD_FAILURE,
        payload: userObj
    })
    