import { userConstants } from '../../constants/user.constants';
const initialState = {
    changePasswordData:{}
 }
 export function changePassword(state = initialState, action) {
    switch (action.type) {
        case userConstants.CHANGE_PASSWORD_REQUEST:
          return { ...state, changePasswordData:action.payload}
        case userConstants.CHANGE_PASSWORD_SUCCESS:
          return { ...state, changePasswordData:action.payload}
        case userConstants.CHANGE_PASSWORD_FAILURE:
          return { ...state, changePasswordData:action.payload}
        default:
          return state
      }
  }
