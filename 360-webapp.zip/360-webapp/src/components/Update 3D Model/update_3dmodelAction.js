import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
//import {List_gamesActions} from "../../components/List Games/list_gamesAction";
export const Update_iplus360Actions = {
    edit_360assets
};
function edit_360assets(userData){
    return dispatch =>{
        dispatch(updatemodelRequest({}))
        userService.update_iplus360_assets(userData).then(
            updatemodelRes =>{
                dispatch(updatemodelResponse(updatemodelRes));
              //  dispatch(List_gamesActions.list_games({page:"1",perPage:"3",status:"live"}))
            },
            error =>{
                dispatch(updatemodelError(error))
            }
         )
      }
    }
    const updatemodelRequest = userObj =>({
        type: userConstants.UPDATE_360ASSETS_REQUEST,
        payload: userObj
    })
    export const updatemodelResponse = userObj =>({
        type: userConstants.UPDATE_360ASSETS_SUCCESS,
        payload: userObj
    })
    const updatemodelError = userObj =>({
        type: userConstants.UPDATE_360ASSETS_FAILURE,
        payload: userObj
    })