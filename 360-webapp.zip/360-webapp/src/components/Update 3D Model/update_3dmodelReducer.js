import { userConstants } from '../../constants/user.constants';
const initialState = {
    updatedmodelData:{}
 }
 export function updateModel(state = initialState, action) {
    switch (action.type) {
        case userConstants.UPDATE_360ASSETS_REQUEST:
          return { ...state, updatedmodelData:action.payload}
        case userConstants.UPDATE_360ASSETS_SUCCESS:
          return { ...state, updatedmodelData:action.payload}
        case userConstants.UPDATE_360ASSETS_FAILURE:
          return { ...state, updatedmodelData:action.payload}
        default:
          return state
      }
  }