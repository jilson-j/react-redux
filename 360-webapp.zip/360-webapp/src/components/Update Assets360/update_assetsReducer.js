import { userConstants } from '../../constants/user.constants';
const initialState = {
    update360AssetsData:{}
 }
 export function update360Object(state = initialState, action) {
    switch (action.type) {
        case userConstants.UPDATE_ASSETS360_OBJECT_REQUEST:
          return { ...state, update360AssetsData:action.payload}
        case userConstants.UPDATE_ASSETS360_OBJECT_SUCCESS:
          return { ...state, update360AssetsData:action.payload}
        case userConstants.UPDATE_ASSETS360_OBJECT_FAILURE:
          return { ...state, update360AssetsData:action.payload}
        default:
          return state
      }
  }