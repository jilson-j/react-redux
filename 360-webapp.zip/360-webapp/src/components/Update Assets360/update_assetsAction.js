import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const update360assetsActions = {
    update360Object
};
function update360Object(data,id_360){
    return dispatch =>{
        dispatch(update360assetsRequest({}))
        userService.update360Assets(data,id_360).then(
            updateassetsRes =>{
                dispatch(update360assetsResponse(updateassetsRes));
            },
            error =>{
                dispatch(update360assetsError(error))
            }
         )
      }
    }
    const update360assetsRequest = userObj =>({
        type: userConstants.UPDATE_ASSETS360_OBJECT_REQUEST,
        payload: userObj
    })
    export const update360assetsResponse = userObj =>({
        type: userConstants.UPDATE_ASSETS360_OBJECT_SUCCESS,
        payload: userObj
    })
    const update360assetsError = userObj =>({
        type: userConstants.UPDATE_ASSETS360_OBJECT_FAILURE,
        payload: userObj
    })