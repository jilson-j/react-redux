import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const List_StatusActions = {
    read_status
};
function read_status(userData){
    return dispatch =>{
        dispatch(listStatusRequest({}))
        userService.list_status(userData).then(
            statusRes =>{
                const data = statusRes.data!=undefined ? statusRes.data:[];
                dispatch(listStatusResponse(data));
            },
            error =>{
                dispatch(listStatusError(error))
            }
         )
      }
    }
    const listStatusRequest = userObj =>({
        type: userConstants.LIST_STATUS_REQUEST,
        payload: userObj
    })
    export const listStatusResponse = userObj =>({
        type: userConstants.LIST_STATUS_SUCCESS,
        payload: userObj
    })
    const listStatusError = userObj =>({
        type: userConstants.LIST_STATUS_FAILURE,
        payload: userObj
    })