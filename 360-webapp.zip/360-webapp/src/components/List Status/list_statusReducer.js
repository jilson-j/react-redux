import { userConstants } from '../../constants/user.constants';
const initialState = {
    statusData:{}
 }
 export function list_status(state = initialState, action) {
    switch (action.type) {
        case userConstants.LIST_STATUS_REQUEST:
          return { ...state, statusData:action.payload}
        case userConstants.LIST_STATUS_SUCCESS:
          return { ...state, statusData:action.payload}
        case userConstants.LIST_STATUS_FAILURE:
          return { ...state, statusData:action.payload}
        default:
          return state
      }
  }