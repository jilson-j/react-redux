import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const Get_iplus360Actions = {
    select_list_iplus360

};
function select_list_iplus360(userData){
    return dispatch =>{
        dispatch(selectlistiplus360Request({}))
        userService.getassets360(userData).then(
            selectedlist =>{
                const data = selectedlist.data!=undefined ? selectedlist.data:{};
                dispatch(selectlistiplus360Response(data));
            },
            error =>{
                dispatch(selectlistiplus360Error(error))
            }
         )
      }
    }
    const selectlistiplus360Request = userObj =>({
        type: userConstants.GET_ASSETS360_REQUEST,
        payload: userObj
    })
    export const selectlistiplus360Response = userObj =>({
        type: userConstants.GET_ASSETS360_SUCCESS,
        payload: userObj
    })
    const selectlistiplus360Error = userObj =>({
        type: userConstants.GET_ASSETS360_FAILURE,
        payload: userObj
    })