import { userConstants } from '../../constants/user.constants';
const initialState = {
     selectedAsset360:{},
 }
 export function select_list_iplus360(state = initialState, action) {
    switch (action.type) {
        case userConstants.GET_ASSETS360_REQUEST:
          return { ...state, selectedAsset360:action.payload}
        case userConstants.GET_ASSETS360_SUCCESS:
          return { ...state, selectedAsset360:action.payload}
        case userConstants.GET_ASSETS360_FAILURE:
          return { ...state, selectedAsset360:action.payload}
        default:
          return state
      }
  }