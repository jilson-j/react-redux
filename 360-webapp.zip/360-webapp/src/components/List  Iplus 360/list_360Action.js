import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const List_iplus360Actions = {
    list_iplus360

};
function list_iplus360(userData){
    return dispatch =>{
        dispatch(listiplus360Request({}))
        userService.listthreesixty(userData).then(
            listthreesixtyres =>{
                const data = listthreesixtyres.data!=undefined ? listthreesixtyres.data:[];
                dispatch(listiplus360Response(data));
            },
            error =>{
                dispatch(listiplus360Error(error))
            }
         )
      }
    }
    const listiplus360Request = userObj =>({
        type: userConstants.LIST_360ASSETS_REQUEST,
        payload: userObj
    })
    export const listiplus360Response = userObj =>({
        type: userConstants.LIST_360ASSETS_SUCCESS,
        payload: userObj
    })
    const listiplus360Error = userObj =>({
        type: userConstants.LIST_360ASSETS_FAILURE,
        payload: userObj
    })
    export const clonelistiplus360Request = userObj =>({
        type: userConstants.CLONE_LIST_360ASSETS_REQUEST,
        payload: userObj
    })