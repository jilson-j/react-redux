import { userConstants } from '../../constants/user.constants';
const initialState = {
     Asset360Data:{},
    clonedAsset360Data:{}
 }
 export function list_iplus360model(state = initialState, action) {
    switch (action.type) {
        case userConstants.LIST_360ASSETS_REQUEST:
          return { ...state, Asset360Data:action.payload}
        case userConstants.LIST_360ASSETS_SUCCESS:
          return { ...state, Asset360Data:action.payload,clonedAsset360Data:action.payload}
        case userConstants.CLONE_LIST_360ASSETS_REQUEST:
          return { ...state, Asset360Data:action.payload}
        case userConstants.LIST_360ASSETS_FAILURE:
          return { ...state, Asset360Data:action.payload}
        default:
          return state
      }
  }