import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const create360assetsActions = {
    createnew360asset
};
function createnew360asset(userData,id_360){
    return dispatch =>{
        dispatch(create360assetsRequest({}))
        userService.create360Assets(userData,id_360).then(
            createassetsRes =>{
                dispatch(create360assetsResponse(createassetsRes));
            },
            error =>{
                dispatch(create360assetsError(error))
            }
         )
      }
    }
    const create360assetsRequest = userObj =>({
        type: userConstants.CREATE_ASSETS360_REQUEST,
        payload: userObj
    })
    export const create360assetsResponse = userObj =>({
        type: userConstants.CREATE_ASSETS360_SUCCESS,
        payload: userObj
    })
    const create360assetsError = userObj =>({
        type: userConstants.CREATE_ASSETS360_FAILURE,
        payload: userObj
    })