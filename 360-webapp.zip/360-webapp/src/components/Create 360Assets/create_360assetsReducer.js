import { userConstants } from '../../constants/user.constants';
const initialState = {
    create360AssetsData:{}
 }
 export function createAssets360(state = initialState, action) {
    switch (action.type) {
        case userConstants.CREATE_ASSETS360_REQUEST:
          return { ...state, create360AssetsData:action.payload}
        case userConstants.CREATE_ASSETS360_SUCCESS:
          return { ...state, create360AssetsData:action.payload}
        case userConstants.CREATE_ASSETS360_FAILURE:
          return { ...state, create360AssetsData:action.payload}
        default:
          return state
      }
  }