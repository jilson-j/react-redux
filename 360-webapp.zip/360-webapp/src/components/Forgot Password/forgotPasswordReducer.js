import { userConstants } from '../../constants/user.constants';
const initialState = {
    forgotPasswordData:{}
 }
 export function forgotPassword(state = initialState, action) {
    switch (action.type) {
        case userConstants.FORGOT_PASSWORD_REQUEST:
          return { ...state, forgotPasswordData:action.payload}
        case userConstants.FORGOT_PASSWORD_SUCCESS:
          return { ...state, forgotPasswordData:action.payload}
        case userConstants.FORGOT_PASSWORD_FAILURE:
          return { ...state, forgotPasswordData:action.payload}
        default:
          return state
      }
  }
