import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const forgotpasswordActions = {
    forgot_password
};
function forgot_password (useremail){
    return dispatch =>{
        dispatch(forgotpasswordRequest({}))
        userService.forgotPassword(useremail).then(
            forgotdata =>{
                dispatch(forgotpasswordResponse(forgotdata));
            },
            error =>{
                dispatch(forgotpasswordError(error))
            }
         )
      }
    }
    const forgotpasswordRequest = userObj =>({
        type: userConstants.FORGOT_PASSWORD_REQUEST,
        payload: userObj
    })
    export const forgotpasswordResponse = userObj =>({
        type: userConstants.FORGOT_PASSWORD_SUCCESS,
        payload: userObj
    })
    const forgotpasswordError = userObj =>({
        type: userConstants.FORGOT_PASSWORD_FAILURE,
        payload: userObj
    })