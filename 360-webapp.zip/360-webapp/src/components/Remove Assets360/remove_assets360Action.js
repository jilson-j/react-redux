import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const remove360assetsActions = {
    remove360Object
};
function remove360Object(id_360,object_id){
    return dispatch =>{
        dispatch(remove360assetsRequest({}))
        userService.remove360Assets(id_360,object_id).then(
            removeassetsRes =>{
                dispatch(remove360assetsResponse(removeassetsRes));
            },
            error =>{
                dispatch(remove360assetsError(error))
            }
         )
      }
    }
    const remove360assetsRequest = userObj =>({
        type: userConstants.REMOVE_ASSETS360_OBJECT_REQUEST,
        payload: userObj
    })
    export const remove360assetsResponse = userObj =>({
        type: userConstants.REMOVE_ASSETS360_OBJECT_SUCCESS,
        payload: userObj
    })
    const remove360assetsError = userObj =>({
        type: userConstants.REMOVE_ASSETS360_OBJECT_FAILURE,
        payload: userObj
    })