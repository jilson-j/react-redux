import { userConstants } from '../../constants/user.constants';
const initialState = {
    remove360AssetsData:{}
 }
 export function delete360Object(state = initialState, action) {
    switch (action.type) {
        case userConstants.REMOVE_ASSETS360_OBJECT_REQUEST:
          return { ...state, remove360AssetsData:action.payload}
        case userConstants.REMOVE_ASSETS360_OBJECT_SUCCESS:
          return { ...state, remove360AssetsData:action.payload}
        case userConstants.REMOVE_ASSETS360_OBJECT_FAILURE:
          return { ...state, remove360AssetsData:action.payload}
        default:
          return state
      }
  }