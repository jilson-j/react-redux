import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const List_release_countActions = {
    read_status_count
};
function read_status_count(){
    return dispatch =>{
        dispatch(liststatuscountRequest({}))
        userService.list_release_flag_count().then(
            listreleasecount =>{
                const data = listreleasecount.data!=undefined ? listreleasecount.data:[];
                dispatch(liststatuscountResponse(data));
            },
            error =>{
                dispatch(liststatuscountError(error))
            }
         )
      }
    }
    const liststatuscountRequest = userObj =>({
        type: userConstants.LIST_STATUS_COUNT_REQUEST,
        payload: userObj
    })
    export const liststatuscountResponse = userObj =>({
        type: userConstants.LIST_STATUS_COUNT_SUCCESS,
        payload: userObj
    })
    const liststatuscountError = userObj =>({
        type: userConstants.LIST_STATUS_COUNT_FAILURE,
        payload: userObj
    })