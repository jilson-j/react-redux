import { userConstants } from '../../constants/user.constants';
const initialState = {
    release_status:{},
 }
 export function list_status_count(state = initialState, action) {
    switch (action.type) {
        case userConstants.LIST_STATUS_COUNT_REQUEST:
          return { ...state, release_status:action.payload}
        case userConstants.LIST_STATUS_COUNT_SUCCESS:
          return { ...state, release_status:action.payload}
        case userConstants.LIST_STATUS_COUNT_FAILURE:
          return { ...state, release_status:action.payload}
        default:
          return state
      }
  }