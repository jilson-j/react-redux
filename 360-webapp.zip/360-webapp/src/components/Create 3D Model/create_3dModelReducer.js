import { userConstants } from '../../constants/user.constants';
const initialState = {
    createmodelData:{}
 }
 export function createmodel(state = initialState, action) {
    switch (action.type) {
        case userConstants.CREATE_360ASSETS_REQUEST:
          return { ...state, createmodelData:action.payload}
        case userConstants.CREATE_360ASSETS_SUCCESS:
          return { ...state, createmodelData:action.payload}
        case userConstants.CREATE_360ASSETS_FAILURE:
          return { ...state, createmodelData:action.payload}
        default:
          return state
      }
  }