import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
import {List_iplus360Actions} from "../List  Iplus 360/list_360Action";
export const Addnew_360AssetsActions = {
    add_new_iplus360
};
function add_new_iplus360(userData){
    return dispatch =>{
        dispatch(createmodelRequest({}))
        userService.create_iplus360_assets(userData).then(
            createmodelRes =>{
                if(createmodelRes.status == 1){
                    dispatch(List_iplus360Actions.list_iplus360({page:"1",perPage:"3",status:"live"}))
                    dispatch(createmodelResponse(createmodelRes));
                }
                dispatch(createmodelResponse(createmodelRes));
            },
            error =>{
                dispatch(createmodelError(error))
            }
         )
      }
    }
    const createmodelRequest = userObj =>({
        type: userConstants.CREATE_360ASSETS_REQUEST,
        payload: userObj
    })
    export const createmodelResponse = userObj =>({
        type: userConstants.CREATE_360ASSETS_SUCCESS,
        payload: userObj
    })
    const createmodelError = userObj =>({
        type: userConstants.CREATE_360ASSETS_FAILURE,
        payload: userObj
    })