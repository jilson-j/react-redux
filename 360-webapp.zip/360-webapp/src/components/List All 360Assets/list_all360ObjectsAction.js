import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const ListAll360AssetsActions = {
    getall360objects
};
function getall360objects(userData){
    return dispatch =>{
        dispatch(listall360assetsRequest({}))
        userService.listall360assets(userData).then(
            listall360objectres =>{
                const data = listall360objectres.data!=undefined ? listall360objectres.data:[];
                dispatch(listall360assetsResponse(data));
            },
            error =>{
                dispatch(listall360assetsError(error))
            }
         )
      }
    }
    const listall360assetsRequest = userObj =>({
        type: userConstants.READ_360ASSETS_REQUEST,
        payload: userObj
    })
    export const listall360assetsResponse = userObj =>({
        type: userConstants.READ_360ASSETS_SUCCESS,
        payload: userObj
    })
    const listall360assetsError = userObj =>({
        type: userConstants.READ_360ASSETS_FAILURE,
        payload: userObj
    })
    