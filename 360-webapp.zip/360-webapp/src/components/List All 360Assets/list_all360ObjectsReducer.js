import { userConstants } from '../../constants/user.constants';
const initialState = {
     all360objectsData:{},
 }
 export function getall360Assets(state = initialState, action) {
    switch (action.type) {
        case userConstants.READ_360ASSETS_REQUEST:
          return { ...state, all360objectsData:action.payload}
        case userConstants.READ_360ASSETS_SUCCESS:
          return { ...state, all360objectsData:action.payload}
        case userConstants.READ_360ASSETS_FAILURE:
          return { ...state, all360objectsData:action.payload}
        default:
          return state
      }
  }