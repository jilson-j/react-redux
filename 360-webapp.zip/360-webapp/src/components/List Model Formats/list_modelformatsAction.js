import { userConstants } from '../../constants/user.constants';
import {userService} from '../../services/user.service';
export const List_modelformatActions = {
    read_model_formats
};
function read_model_formats(groupname){
    return dispatch =>{
        dispatch(listmodelformatRequest({}))
        userService.list_3dmodel_formats(groupname).then(
            listmodelformat =>{
                const data = listmodelformat.data!=undefined ? listmodelformat.data:[];
                dispatch(listmodelformatResponse(data));
            },
            error =>{
                dispatch(listmodelformatError(error))
            }
         )
      }
    }
    const listmodelformatRequest = userObj =>({
        type: userConstants.LIST_MODEL_FORMAT_REQUEST,
        payload: userObj
    })
    export const listmodelformatResponse = userObj =>({
        type: userConstants.LIST_MODEL_FORMAT_SUCCESS,
        payload: userObj
    })
    const listmodelformatError = userObj =>({
        type: userConstants.LIST_MODEL_FORMAT_FAILURE,
        payload: userObj
    })