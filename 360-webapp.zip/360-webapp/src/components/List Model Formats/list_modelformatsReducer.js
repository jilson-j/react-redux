import { userConstants } from '../../constants/user.constants';
const initialState = {
    modelformatsData:{},
 }
 export function list_formats(state = initialState, action) {
    switch (action.type) {
        case userConstants.LIST_MODEL_FORMAT_REQUEST:
          return { ...state, modelformatsData:action.payload}
        case userConstants.LIST_MODEL_FORMAT_SUCCESS:
          return { ...state, modelformatsData:action.payload}
        case userConstants.LIST_MODEL_FORMAT_FAILURE:
          return { ...state, modelformatsData:action.payload}
        default:
          return state
      }
  }