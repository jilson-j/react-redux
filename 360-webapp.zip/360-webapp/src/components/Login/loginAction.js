import { userConstants } from "../../constants/user.constants";
import { userService } from "../../services/user.service";
import history from "../../helpers/history";

export const userActions = {
  userEmail,
  login,
  logout,
  userRedirect
};

function userRedirect() {
  return dispatch => {
    dispatch(loginRequest({}));
    history.push("/")
  }
}

function userEmail(email) {
  return dispatch => {
    dispatch(userEmailSuccess(email));
    history.push("/password");
  };
}

function login(email, password) {
  return dispatch => {
    dispatch(loginRequest({}));
    userService.login(email, password).then(
      user => {
        userService.readcustomerprofile(user.token).then(
          customer =>{
            var customer_record = customer.data.customer_roles!==undefined ? customer.data.customer_roles:[];
            customer_record.filter(roles=>{
                if(roles === "iplus360_1"){
                  var set_roles = {roles:roles,games_default:true}
                  localStorage.setItem('user_roles', JSON.stringify(set_roles));
                  history.push('/360_portal')
                }
                else if(roles === "iplus360_2"){
                  var set_roles = {roles:roles,games_default:true,games_createEdit:true}
                  localStorage.setItem('user_roles', JSON.stringify(set_roles));
                  history.push('/360_portal')
                }
                else if(roles === "iplus360_3"){
                  var set_roles = {roles:roles,games_default:true,games_createEdit:true,games_remove:true}
                  localStorage.setItem('user_roles', JSON.stringify(set_roles));
                  history.push('/360_portal')
                }
                else if(roles === "iplus360_4"){
                  var set_roles = {roles:roles,games_default:true,games_createEdit:true,games_super_admin:true}
                  localStorage.setItem('user_roles', JSON.stringify(set_roles));
                  history.push('/360_portal')
                }
                else{
                  dispatch(loginError("No access to this page!.Please contact Admin."))
                }
            })
            //  dispatch(loginUser(user))
          }
        )
      },
      error => {
        console.log("error actions--",error)
        dispatch(loginError(error));
      }
    );
  };
}

const userEmailSuccess = userObj => ({
  type: userConstants.USER_EMAIL,
  payload: userObj
});

const loginRequest = userObj => ({
  type: userConstants.LOGIN_REQUEST,
  payload: userObj
});

const loginUser = userObj => ({
  type: userConstants.LOGIN_SUCCESS,
  payload: userObj
});

export const loginError = userObj => ({
  type: userConstants.LOGIN_FAILURE,
  payload: userObj
});

function logout() {
  userService.logout();
  history.push("/");
  return { type: userConstants.LOGOUT };
}
