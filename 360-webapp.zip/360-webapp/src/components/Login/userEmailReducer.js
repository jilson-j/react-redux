import { userConstants } from '../../constants/user.constants';

//let user = JSON.parse(localStorage.getItem('user'));
const initialState = {
    userEmail: {}
}
export function userEmail(state = initialState, action) {

    switch (action.type) {
        case userConstants.USER_EMAIL:
            return { ...state, userEmail: action.payload }
        default:
            return state
    }
}