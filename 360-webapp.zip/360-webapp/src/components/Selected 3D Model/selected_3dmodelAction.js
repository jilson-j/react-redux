import { userConstants } from '../../constants/user.constants';
    export const selectmodelResponse = userObj =>({
        type: userConstants.SELECT_360ASSETS_SUCCESS,
        payload: userObj
    })