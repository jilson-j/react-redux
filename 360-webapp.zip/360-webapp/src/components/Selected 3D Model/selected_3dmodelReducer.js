import { userConstants } from '../../constants/user.constants';
const initialState = {
    selectedmodelData:{
      name_360:"",
      description_360:"",
      package_owner:"",
      package_writer:"",
      release_flag:"",
      search_tags:[],
      country_id:0
    }
 }
 export function selectedModelDetails(state = initialState, action) {
    switch (action.type) {
        case userConstants.SELECT_360ASSETS_SUCCESS:
          return { ...state, selectedmodelData:action.payload}
        default:
          return state
      }
  }