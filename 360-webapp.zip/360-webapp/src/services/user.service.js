var path = require('../constants/user.constants')
export const userService = {
    register,
    login,
    logout,
    forgotPassword,
    changePassword,
    readcustomerprofile,
    listthreesixty,
    create_iplus360_assets,
    update_iplus360_assets,
    list_status,
    delete_iplus360_assets,
    list_3dmodel_formats,
    list_release_flag_count,
    listall360assets,
    getassets360,
    create360Assets,
    update360Assets,
    remove360Assets
};
// Register Service
async function register(userData){
   const requestOptions = {
       method:'POST',
       headers:{
        'Content-Type': 'application/json',
        'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
       },
       body:JSON.stringify({
        email:userData.email,
        name:userData.name,
        password:userData.password,
        organization:userData.organization,
        customer_roles:userData.customer_roles
       })
   };
   return await fetch(path.userConstants.REGISTER,requestOptions)
   .then(handleResponse)
   .then(register_data=>{
       return register_data
   })
}
// Login Service
async function login(email, password) {
    const requestOptions = {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
         },
        body: JSON.stringify({
            email: email,
            password: password,
            channel_id:3001
        })
    };

    return await fetch(path.userConstants.LOGIN, requestOptions)
        .then(handleResponse)
        .then(user => {
           localStorage.setItem('token', user.token);
           localStorage.setItem('username',user.data.customer_name)
           localStorage.setItem('useremail',user.data.customer_email)
            return user;
        });
}
// change password service
async function changePassword(userData){
    const requestOptions = {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'authorization': userData.token
         },
        body: JSON.stringify({
            oldPassword: userData.old_password,
            newPassword: userData.new_password,
            confirmPassword: userData.confirm_password
        })
    };
    return await fetch(path.userConstants.CHANGE_PASSWORD,requestOptions)
    .then(handleResponse)
    .then(changePassword_data=>{
        return changePassword_data
    })
}
async function readcustomerprofile(token){
    const requestOptions ={
        method: 'POST',
        headers:{
            'Content-Type': 'application/json',
            'authorization': token
        }
    }
    return await fetch(path.userConstants.CUSTOMER_READ, requestOptions)
    .then(handleResponse)
    .then(customer => {
        localStorage.setItem('organization',customer.data.customer_organization)
        return customer;
    });
}
async function forgotPassword(useremail){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
         email:useremail
        })
    };
    return await fetch(path.userConstants.FORGOT_PASSWORD,requestOptions)
    .then(handleResponse)
    .then(forgotdata=>{
        return forgotdata
    })
}
async function listthreesixty(data){
    console.log("service data",data);
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify(data)
    };
    return await fetch(path.userConstants.LIST_360ASSETS,requestOptions)
    .then(handleResponse)
    .then(listthreesixtyres=>{
        return listthreesixtyres
    })
}
async function create_iplus360_assets(data){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            name_360:data.name_360,
            description_360:data.description_360,
            release_flag:data.release_flag,
            country_id:1001,
            release_flag:data.release_flag,
            search_tags:data.search_tags,
            package_writer:localStorage.getItem("useremail") ? localStorage.getItem("useremail") :"",
            package_owner:localStorage.getItem("organization") ? localStorage.getItem("organization"):""
        })
    };
    return await fetch(path.userConstants.CREATE_360COVER,requestOptions)
    .then(handleResponse)
    .then(createmodelRes=>{
        return createmodelRes
    })
}
async function update_iplus360_assets(data,compatibility){
    console.log("service--",data);
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            id_360:data.id_360,
            name_360:data.name_360,
            description_360:data.description_360,
            release_flag:data.release_flag,
            country_id:1001,
            release_flag:data.release_flag,
            search_tags:data.search_tags,
            package_writer:localStorage.getItem("useremail") ? localStorage.getItem("useremail") :"",
            package_owner:localStorage.getItem("organization") ? localStorage.getItem("organization"):""
        })
    };
    return await fetch(path.userConstants.UPDATE_360COVER,requestOptions)
    .then(handleResponse)
    .then(updatemodelRes=>{
        return updatemodelRes
    })
}
async function getassets360(id_360){
    const requestOptions = {
        method:'GET',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        }
    };
    return await fetch(path.userConstants.SELECT_LIST_360ASSETS+id_360,requestOptions)
    .then(handleResponse)
    .then(selectedlist=>{
        return selectedlist
    }) 
}
async function create360Assets(data,id_360){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            id_360:id_360,
            type:data.type,
            name:data.name,
            media:data.media,
            media_description:data.media_description,
            item_tags:data.item_tags,
            package_writer:localStorage.getItem("useremail") ? localStorage.getItem("useremail") :"",
        })
    };
    return await fetch(path.userConstants.CREATE_360ASSETSOBJECT,requestOptions)
    .then(handleResponse)
    .then(createassetsRes=>{
        return createassetsRes
    })
}
async function update360Assets(data,id_360){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            id_360:id_360,
            _id:data._id,
            type:data.type,
            name:data.name,
            media:data.media,
            media_description:data.media_description,
            item_tags:data.item_tags,
            package_writer:localStorage.getItem("useremail") ? localStorage.getItem("useremail") :"",
        })
    };
    return await fetch(path.userConstants.UPDATE_360ASSETSOBJECT,requestOptions)
    .then(handleResponse)
    .then(updateassetsRes=>{
        return updateassetsRes
    })
}
async function remove360Assets(id_360,object_id){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            id_360:id_360,
            _id:object_id,
            package_writer:localStorage.getItem("useremail") ? localStorage.getItem("useremail") :"",
        })
    };
    return await fetch(path.userConstants.REMOVE_360ASSETSOBJECT,requestOptions)
    .then(handleResponse)
    .then(removeassetsRes=>{
        return removeassetsRes
    })
}
async function list_status(groupname){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            group_name:groupname
        })  
    };
    return await fetch(path.userConstants.LIST_STATUS,requestOptions)
    .then(handleResponse)
    .then(statusRes=>{
        return statusRes
    }) 
}
async function delete_iplus360_assets (id_360){
    console.log("ARId--",id_360);
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            id_360:id_360
        })  
    };
    return await fetch(path.userConstants.REMOVE_360COVER,requestOptions)
    .then(handleResponse)
    .then(removemodelres=>{
        return removemodelres
    }) 
}
async function list_3dmodel_formats (groupname){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
        body:JSON.stringify({
            group_name:groupname
        })  
    };
    return await fetch(path.userConstants.LIST_STATUS,requestOptions)
    .then(handleResponse)
    .then(listmodelformat=>{
        return listmodelformat
    }) 
}
async function list_release_flag_count (){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        },
    };
    return await fetch(path.userConstants.LIST_STATUS_COUNT,requestOptions)
    .then(handleResponse)
    .then(listreleasecount=>{
        return listreleasecount
    }) 
}
async function listall360assets (){
    const requestOptions = {
        method:'POST',
        headers:{
         'Content-Type': 'application/json',
         'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
        }
    };
    return await fetch(path.userConstants.LIST_360ASSETS,requestOptions)
    .then(handleResponse)
    .then(listall360objectres=>{
        return listall360objectres
    }) 
}
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user_roles');
    localStorage.removeItem('organization');
}
function handleResponse(response) {

    console.log('Response->',response)

    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                logout();
            }
            console.log("Response text--",data.message)
            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }
        console.log('Data Methof', data)
        return data;
    });
}