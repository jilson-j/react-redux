import '../static/css/uikit_min.css';
import '../static/css/splitter.css';