import React, { useState } from "react";
import './changePassword.css';
import { useDispatch, useSelector } from "react-redux";
import ModelIcon from "../../../static/images/3dModal-logo.png";
import {ChangePasswordActions} from "../../../components/Change Password/changePasswordAction";
import {changepasswordResponse} from "../../../components/Change Password/changePasswordAction";
import history from "../../../helpers/history";
import UIkit from "uikit";
export default function ChangePassword() {
    const dispatch = useDispatch();
    const change_password = useSelector(state => state.changePasswordReducer);
    const changePassword_response =  change_password.changePasswordData!==undefined ? change_password.changePasswordData:{};
    const [ChangePassword,setChangePassword] = useState({
        token:localStorage.getItem("token") ? localStorage.getItem("token"): ' ',
        old_password:"",
        new_password:"",
        confirm_password:"",
    })
    if(Object.keys(changePassword_response).length>0){
        UIkit.modal("#change_password_modal").show();
    }
const submit_btn = (e) =>{
    if (!ChangePassword.old_password) {
        document.getElementById('error_msg').innerHTML = 'Please enter the old password !!'
        document.getElementById('error_msg').style.color = 'red';
        document.getElementById('form_error').style.borderColor = "red";
        return false;
    }
    else if (!ChangePassword.new_password) {
        document.getElementById('error_msg').innerHTML = 'Please enter the new password !!'
        document.getElementById('error_msg').style.color = 'red';
        document.getElementById('form_error').style.borderColor = "red";
        return false;
    }
    else if (!ChangePassword.confirm_password) {
        document.getElementById('error_msg').innerHTML = 'Please enter the confirm password !!'
        document.getElementById('error_msg').style.color = 'red';
        document.getElementById('form_error').style.borderColor = "red";
        return false;
    }

    else if (ChangePassword.new_password !== ChangePassword.confirm_password) {
        document.getElementById('error_msg').innerHTML = 'Your new password and confirm password does not match !!'
        document.getElementById('error_msg').style.color = 'red';
        return false;
    }
    else{
        document.getElementById('error_msg').innerHTML = "";
       dispatch(ChangePasswordActions.change_password(ChangePassword));
    }
}
const submitBtn = (e) =>{
   dispatch(changepasswordResponse({}))
   history.push('/')
   UIkit.modal("#change_password_modal").hide();
}
 return(
    <div>
    <div
    className="uk-section-muted uk-flex uk-flex-middle uk-animation-fade"
    uk-height-viewport="">
    <div className="uk-width-1-1">
        <div className="uk-container">
            <div className="uk-grid-margin uk-grid uk-grid-stack" uk-grid="">
                <div className="uk-width-1-1@m loginpage uk-first-column">
                    <div className="uk-margin uk-width-large uk-margin-auto uk-card uk-card-default uk-card-body changePassword_card_height uk-padding-remove">
                    <div className='uk-clearfix'></div>
                       <div className="backicon uk-float-right paddingbackicon">
                             <a onClick={(e) => history.push("/360_portal")}>
                                 <span uk-icon="icon: arrow-left; ratio: 1.3" class="uk-icon"></span>
                             </a>
                        </div>
                        <div className='uk-clearfix'></div>
                     <div className="custom_inner_padding">
                        <div className="uk-card-title uk-text-center">
                             <img src={ModelIcon} alt="logo" className="ar_image"/>
                       </div>
                        <div className="uk-text-small uk-text-center" style={{ fontSize: '16px' }}>
                          Change password here...
                        </div>
                        <div className="uk-margin-top">
                             <label className="label_name">Old Password
                             </label>
                             <div className="uk-inline uk-width-1-1 custom_input">
                                 <a class="uk-form-icon" href="#" uk-icon="icon: lock"></a>
                                  <input id="form_error" className="uk-input uk-form-normal boder_rad" type="password" value={ChangePassword.old_password} onChange={(e)=>setChangePassword({...ChangePassword,old_password:e.target.value})}/>
                             </div>
                             <label className="label_name">New Password</label>
                             <div className="uk-inline uk-width-1-1 custom_input">
                                <a class="uk-form-icon" href="#" uk-icon="icon: unlock"></a>
                                  <input id="form_error" className="uk-input uk-form-normal boder_rad" type="password" value={ChangePassword.new_password} onChange={e=>setChangePassword({...ChangePassword,new_password:e.target.value})} />
                             </div>
                             <label className="label_name">Confirm Password</label>
                              <div className="uk-inline uk-width-1-1 custom_input">
                                 <a class="uk-form-icon" href="#" uk-icon="icon: unlock"></a>
                                  <input id="form_error" className="uk-input uk-form-normal boder_rad" type="password" value={ChangePassword.confirm_password} onChange={e=>setChangePassword({...ChangePassword,confirm_password:e.target.value})}/>
                             </div>
                             <div className="uk-text-center uk-margin-top">
                                 <button id='next_btn' className="uk-button before_btn uk-width-1-3 boder_rad" onClick={e=>submit_btn(e)}>
                                      Submit 
                                 </button>
                             </div>
                         </div>
                        <span className="uk-text-center"><p id="error_msg"></p></span>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="change_password_modal" uk-modal="">
    <div class="uk-modal-dialog uk-modal-body">
          <button class="uk-modal-close-default" type="button" uk-close="" onClick={()=>dispatch(changepasswordResponse({}))}></button>
          {
              Object.keys(changePassword_response).length>0?(
           <div class="uk-alert-primary" uk-alert="">
                <p>{changePassword_response.message}</p>
            </div>
             ):null
          }
        <p class="uk-text-center">
            <button class="save_btn" type="button" onClick={e=>submitBtn(e)}>OK</button>
        </p>
    </div>
   </div>
</div>
 )
}