import React, { useState , useEffect} from "react";
import "./Login.css";
import { useDispatch, useSelector } from "react-redux";
import { userActions ,loginError} from "../../../components/Login/loginAction";
import ModelIcon from "../../../static/images/3dModal-logo.png";
import { forgotpasswordActions } from "../../../components/Forgot Password/forgotPasswordAction";
import history from "../../../helpers/history";
import UIkit from "uikit";
export default function Password() {
  const [password, setpassword] = useState("");
  const [useremail, setEmail] = useState("");
  const [toggleShowhidebtn, settoggleShowhidebtn] = useState(false)

  const user_email = useSelector((state) => state.userEmailReducer);
  const login_response = useSelector((state) => state.loginReducer);

  const login_check =
    login_response.currentUser !== undefined ? login_response.currentUser : {};
  const forgot_password = useSelector((state) => state.forgotPasswordReducer);
  const forgotpass_response =
    forgot_password.forgotPasswordData !== undefined
      ? forgot_password.forgotPasswordData
      : {};
  const dispatch = useDispatch();
  var nameCapitalized = "";
  if (Object.keys(user_email.userEmail).length === 0) {
    dispatch(userActions.userRedirect());
  } else {
    const user_name = user_email.userEmail.split("@")[0];
    nameCapitalized = user_name.charAt(0).toUpperCase() + user_name.slice(1);
  }
  const firstName =
    nameCapitalized === "" ||
    nameCapitalized === null ||
    nameCapitalized === undefined
      ? ""
      : "Hi " + nameCapitalized;
  const email =
    Object.keys(user_email.userEmail).length === 0 ? "" : user_email.userEmail;

  useEffect(() => {
    if(Object.keys(login_check).length>0)
    {
      document.getElementById('error_msg').innerHTML = login_check;
      document.getElementById("error_msg").style.color = "red";
      document.getElementById('danger').style.backgroundColor = "#fef4f6";
    }
    if(Object.keys(forgotpass_response).length>0 && forgotpass_response.status ==0){
      UIkit.notification({message: forgotpass_response.message, status: 'danger',timeout:'2000'});
   }
   else if(forgotpass_response.status ==1){
     UIkit.notification({message: forgotpass_response.message , status: 'success',timeout:'2000'});
   }
  }, [login_check,forgotpass_response])

  if (Object.keys(login_check).length > 0) {
    document.getElementById("error_msg").innerHTML = login_check;
    document.getElementById("error_msg").style.color = "red";
  }
  const loginAction = (e) => {
    e.preventDefault();
    if (password === "") {
      document.getElementById("error_msg").innerHTML = "Please enter password";
      document.getElementById("error_msg").style.color = "red";
      document.getElementById('danger').style.backgroundColor = "#fef4f6";
      setTimeout(() => {
        document.getElementById("error_msg").innerHTML = "";
        document.getElementById('error_msg').style.color = "";
        document.getElementById('danger').style.backgroundColor = "transparent";
        }, 2000);
    } else {
      dispatch(userActions.login(email, password));
      setTimeout(() => {
         dispatch(loginError({}));
      }, 2000);
    }
  };
  const sendbtn = (e) => {
    console.log("Event--", email);
    var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
    if (useremail === "") {
      document.getElementById("error").innerHTML = "Please enter email address";
      document.getElementById("error").style.color = "red";
      document.getElementById("form_error_model").style.borderColor = "red";
      setTimeout(() => {
        document.getElementById("error").innerHTML = "";
        document.getElementById("error").style.color = "";
         document.getElementById("form_error_model").style.borderColor = "";
      }, 3000);
    } else if (regexEmail.test(useremail)) {
      document.getElementById("error").innerHTML = "";
      dispatch(forgotpasswordActions.forgot_password(useremail));
      document.getElementById("form_error_model").style.borderColor = "";
    } else {
      document.getElementById("error").innerHTML =
        "Please enter valid email address";
      document.getElementById("error").style.color = "red";
      document.getElementById("form_error_model").style.borderColor = "red";
      setTimeout(() => {
        document.getElementById("error").innerHTML = "";
        document.getElementById("error").style.color = "";
         document.getElementById("form_error_model").style.borderColor = "";
      }, 3000);
    }
  };
  const togglePasswordVisiblity = () => {
    settoggleShowhidebtn(toggleShowhidebtn ? false : true);
  };
  return (
    <div>
      <div
        className="uk-section uk-section-muted uk-flex uk-flex-middle uk-animation-fade"
        uk-height-viewport=""
      >
        <div className="uk-width-1-1">
          <div className="uk-container">
            <div className="uk-grid-margin uk-grid uk-grid-stack" uk-grid="">
              <div className="uk-width-1-1@m loginpage uk-first-column">
                <div className="uk-margin uk-width-large uk-margin-auto uk-card uk-card-default uk-card-body uk-padding-remove">
                  <div className="backicon uk-float-right paddingbackicon">
                    <a onClick={(e) => history.push("/")}>
                      <span uk-icon="icon: arrow-left; ratio: 1.3" class="uk-icon"></span>
                    </a>
                  </div>
                  <div className="clear"></div>
                  <div className="custom_inner_padding">
                    <div className="uk-card-title uk-text-center">
                       <img src={ModelIcon} alt="logo" className="ar_image"/>
                    </div>
                    <div className="uk-text-small uk-text-center portalcs">
                      Portal
                    </div>
                    <div className="uk-margin-small-top uk-text-small uk-text-center">
                      {firstName}
                    </div>
                    <div className="uk-text-small uk-text-center">{email}</div>
                    <div>
                      <div className="uk-margin-small-bottom">
                        <div className="uk-inline uk-width-1-1 uk-margin-top">
                         <a class="uk-form-icon" uk-icon="icon: lock"></a>
                          <input
                            className="uk-input uk-form-normal bordercs"
                            type={toggleShowhidebtn ? "text" : "password"}
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setpassword(e.target.value)}
                            required
                          />
                             <a class={"uk-form-icon uk-form-icon-flip "+(toggleShowhidebtn ? "eyeicon" : "visible_eye" )} onClick={()=>togglePasswordVisiblity()}></a>
                        </div>
                      </div>
                      <div className="uk-text-small edit uk-text-right">
                        <a uk-toggle="target: #forgot_password_modal">
                          Forgot Password
                        </a>
                      </div>
                      <div id="danger" className="uk-text-center">
                        <span id="error_msg"></span>
                      </div>
                      <div className="uk-text-center uk-margin-top">
                        <button id="next_btn"
                          className="uk-button login_btn signin_width BorderRad"
                          onClick={loginAction}
                        >
                          LOGIN WITH IPLUS
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footerDiv">
          <div className="">
            <p>Powered by: LDR Technology, Singapore. 2019 - 2020</p>
          </div>
        </div>
      </div>
      <div id="forgot_password_modal" uk-modal="">
        <div class="uk-modal-dialog uk-modal-body uk-width-large">
          <button
            class="uk-modal-close-default"
            type="button"
            uk-close=""
          ></button>
           <div class="headdiv">IPLUS Password Recovery!</div>
           <div className="uk-margin-small-top">
                 <p>Give us your registered email address and we'll be sending you the temporary password to login!!</p>
          </div>
          
          <div className="uk-inline uk-width-1-1 uk-margin-top uk-margin-bottom">
            <a class="uk-form-icon" uk-icon="icon: mail"></a>
            <input
              id="form_error_model"
              class="uk-input BorderRad"
              type="text"
              placeholder="Enter your email"
              value={useremail}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <span className="uk-text-center">
            <p id="error"></p>
          </span>
          <div class="uk-text-center">
            <button class="save_btn" type="button" onClick={(e) => sendbtn(e)}>
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
