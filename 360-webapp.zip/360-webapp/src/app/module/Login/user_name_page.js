import React, { useState } from "react";
import { useDispatch } from "react-redux";
import "./Login.css";
import ModelIcon from "../../../static/images/3dModal-logo.png";
import { userActions } from "../../../components/Login/loginAction";
import IPlus from "../../../static/images/iplus.png";
export default function UserName(){
    const [user_email, setuser_email] = useState('');
    const nextAction =() =>{
        var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
        if (user_email === "") {
            document.getElementById('alert_msg').innerHTML="Please enter email!";
            document.getElementById('alert_msg').style.color="red";
            document.getElementById('danger').style.backgroundColor = "#fef4f6";
            setTimeout(() => {
                document.getElementById('alert_msg').innerHTML="";
                document.getElementById('alert_msg').style.color="";
                document.getElementById('danger').style.backgroundColor = "transparent"
            }, 3000);
        }
       else if(regexEmail.test(user_email)){
            document.getElementById("alert_msg").innerHTML = "";
            document.getElementById('alert_msg').style.color="";
            document.getElementById('danger').style.backgroundColor = "transparent"
            dispatch(userActions.userEmail(user_email));
        }
        else{
            document.getElementById('alert_msg').innerHTML="Please enter valid email!";
            document.getElementById('alert_msg').style.color="red";
            document.getElementById('danger').style.backgroundColor = "#fef4f6"
            setTimeout(() => {
                document.getElementById('alert_msg').innerHTML="";
                document.getElementById('danger').style.backgroundColor = "transparent"
            }, 3000);
        }
    }
    const dispatch = useDispatch();
    return(
        <div>
        <div
            className="uk-section uk-section-muted uk-flex uk-flex-middle uk-animation-fade"
            uk-height-viewport="">
            <div className="uk-width-1-1">
                <div className="uk-container">
                    <div className="uk-grid-margin uk-grid uk-grid-stack" uk-grid="">
                        <div className="uk-width-1-1@m loginpage">
                            <div className="uk-margin uk-width-large uk-margin-auto uk-card uk-card-default uk-card-body cardHeight uk-padding-remove">
                            <div className="backicon uk-float-right paddingbackicon">
                                <span className="iplus_space">
                                    <img src={IPlus} alt="iplus" className="iplusimg"/>
                                </span>
                            </div>
                                <div className="uk-clearfix"></div>
                            <div className="custom_inner_padding">
                                <div className="uk-card-title uk-text-center">
                                    <img src={ModelIcon} alt="logo" className="ar_image"/>
                                </div>
                                <div className="uk-text-small uk-text-center portalcs">Portal</div>
                                <div className="uk-text-center" style={{ fontSize: '10px' }}>
                                    Sign in to continue ...
                                </div>
                                <div>
                                    <div className="">
                                        <div className="uk-inline uk-width-1-1 uk-margin-top uk-margin-bottom">
                                           <a class="uk-form-icon" uk-icon="icon: mail"></a>
                                            <input id="form_error" className="uk-input uk-form-normal bordercs" type="text"
                                                value={user_email} onChange={(e)=>setuser_email(e.target.value)}
                                                placeholder="User Name or Email"/>
                                        </div>
                                    </div>
                                    <div id="danger" className="uk-text-center">
                                        <span id="alert_msg"></span>
                                    </div>
                                    <div className="uk-text-center uk-margin-top">
                                        <button id='next_btn' className="uk-button login_btn uk-margin-bottom BorderRad signin_width" onClick={(e)=>nextAction(e)}>
                                           LOGIN WITH IPLUS
                                       </button>
                                    </div>
                                    <div className="clear"></div>
                                </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="footerDiv">
            <div className="">
                <p>Powered by: LDR Technology, Singapore. 2019 - 2020</p>
            </div>
        </div>
    </div>
    )
}