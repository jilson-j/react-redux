import React,{useState,useEffect} from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useParams} from "react-router";
import { Pannellum } from "pannellum-react";
import ReactPlayer from "react-player";
import {create360assetsActions,create360assetsResponse} from "../../../components/Create 360Assets/create_360assetsAction";
import {Get_iplus360Actions,selectlistiplus360Response} from "../../../components/Get Selected Assets360/get_asssets360Action";
import {update360assetsActions,update360assetsResponse} from "../../../components/Update Assets360/update_assetsAction";
import {remove360assetsActions,remove360assetsResponse} from "../../../components/Remove Assets360/remove_assets360Action";
import CreateForm from "./create_360assets_form";
import history from "../../../helpers/history";
import UIkit from 'uikit';
export default function Iplus360Details() {

     let { id_360 } = useParams();
    console.log("id",id_360)

    const user_roles = localStorage.getItem("user_roles") ? JSON.parse(localStorage.getItem("user_roles")) : "";
    
    const [buttonLabel, setbuttonLabel] = useState("Create");
    const [selectedItemIndex, setselectedItemIndex] = useState(null);
    const [autoplay,setautoplay]= useState(false);
    const initialState ={
        _id:'',
        type : "360_Image", 
        name : "", 
        media: "", 
        media_description : "", 
        item_tags : []
    }
    const [assets360, setassets360] = useState(initialState);

    useEffect(() => {
      dispatch(Get_iplus360Actions.select_list_iplus360(id_360))
      var getscreenheight = window.innerHeight;
      var topbar = document.getElementsByClassName('topheight')[0].offsetHeight;
      document.getElementsByClassName('modelscroll')[0].style.height=getscreenheight + 'px';
      document.getElementsByClassName('page_scroll')[0].style.height =  getscreenheight-topbar - 100 + 'px';
    }, [])

    //Select List 360 assets from store

    const GetSelected360Assets = useSelector(state => state.GetSelected360Assets);
    const AssetsDetails = GetSelected360Assets.selectedAsset360!==undefined ? GetSelected360Assets.selectedAsset360 :{}
    
    const Create360Object = useSelector(state => state.Create360Object);
    const create360AssestRes = Create360Object.create360AssetsData!==undefined ?  Create360Object.create360AssetsData:{}
    const Update360AssetObject = useSelector(state => state.Update360AssetObject);
    const update360objectRes = Update360AssetObject.update360AssetsData!==undefined ? Update360AssetObject.update360AssetsData:{};
    const Remove360Object = useSelector(state => state.Remove360Object);
    const removeobjectRes =  Remove360Object.remove360AssetsData!==undefined ? Remove360Object.remove360AssetsData:{};

    useEffect(() => {
      if(Object.keys(create360AssestRes).length>0&&create360AssestRes.status==0){
        UIkit.notification({message: create360AssestRes.message, status: 'danger',timeout:'2000'});
      }
       else if(create360AssestRes.status == 1){
        UIkit.notification({message: 'You have created 360 Object Successfully!', status: 'success',timeout:'2000'});
      }
      if(Object.keys(update360objectRes).length>0&&update360objectRes.status==0){
        UIkit.notification({message: update360objectRes.message, status: 'danger',timeout:'2000'});
      }
       else if(update360objectRes.status == 1){
        UIkit.notification({message: 'You have updated 360 Object Successfully!', status: 'success',timeout:'2000'});
      }
      if(Object.keys(removeobjectRes).length>0&&removeobjectRes.status==0){
        UIkit.notification({message: removeobjectRes.message, status: 'danger',timeout:'2000'});
      }
       else if(removeobjectRes.status == 1){
        UIkit.notification({message: 'You have removed 360 Object Successfully!', status: 'success',timeout:'2000'});
      }
    }, [create360AssestRes,update360objectRes,removeobjectRes])


    const create_games =(e) =>{
        setbuttonLabel('Create');
        setassets360(initialState);
        document.getElementById('details_card').style.display="none";
        document.getElementById('create_games_model').style.display="block";
    }
    const edit_game =(items,index) =>{
        setselectedItemIndex(index)
        setassets360(items);
        setbuttonLabel('Update');
        document.getElementById('details_card').style.display="none";
        document.getElementById('create_games_model').style.display="block";
      }
    const updateGameFun = (e) =>{
        //update store
        var getItem = GetSelected360Assets.selectedAsset360
         getItem.assets_360.map((ites,index)=>{
           if(index == selectedItemIndex){
              ites.type = assets360.type
              ites.name = assets360.name
              ites.media = assets360.media
              ites.media_description = assets360.media_description
              ites.item_tags = assets360.item_tags
           }
           return;
        })
        dispatch(selectlistiplus360Response(getItem))
          
       //close the form
       document.getElementById('details_card').style.display="block";
       document.getElementById('create_games_model').style.display="none";

        if(assets360._id !== ''){
            //API call
            dispatch(update360assetsActions.update360Object(assets360,id_360))
            setTimeout(() => {
                dispatch(update360assetsResponse({}))
               setassets360(initialState);
            }, 2000);
         }
    }
    const createGameFun =(e) =>{
            if(assets360.name == ""){
              UIkit.notification({message: "Please give name for 360 Assets", status: 'danger',timeout:'2000'});
             }
             else if(assets360.media_description == "") {
              UIkit.notification({message: "Please give description for 360 Assets", status: 'danger',timeout:'2000'});
             }
             else if(assets360.media == ""){
              UIkit.notification({message: "Please add media!.", status: 'danger',timeout:'2000'});
             }
             else if(assets360.media.includes('blob') == true){
              UIkit.notification({message: "Please upload the media files!.", status: 'danger',timeout:'2000'});
             }
             else{
               //update store
                var getItem = GetSelected360Assets.selectedAsset360
                getItem.assets_360.push(assets360);
                dispatch(selectlistiplus360Response(getItem))
               //API call
                dispatch(create360assetsActions.createnew360asset(assets360,id_360))
              setTimeout(() => {
                 setassets360(initialState);
                 dispatch(create360assetsResponse({}))
              }, 2000);

              //Close Form
              document.getElementById('details_card').style.display="block";
              document.getElementById('create_games_model').style.display="none";
             }
    }
    const close_form = (e) =>{
      document.getElementById('details_card').style.display="block";
      document.getElementById('create_games_model').style.display="none";
    }
    const delete360Object = () =>{
      
      //Update store
      var getItem = GetSelected360Assets.selectedAsset360
      getItem.assets_360.splice(selectedItemIndex,1);
      dispatch(selectlistiplus360Response(getItem))

      //close the form
      document.getElementById('details_card').style.display="block";
      document.getElementById('create_games_model').style.display="none";
      //API call
      if(assets360._id !== ''){
        //API call
        dispatch(remove360assetsActions.remove360Object(id_360,assets360._id))
        setTimeout(() => {
            dispatch(remove360assetsResponse({}))
            setassets360(initialState);
        }, 2000);
     }
       
    }
    const dispatch = useDispatch();
    return (
     <div>
       <div id="details_card" display={{display:'block'}}>
        <div className="uk-text-center bgtheme" style={{height:'100vh'}}>
          <div className="uk-width-expand@m">
             <div className="uk-card  uk-card-body uk-padding-remove-bottom uk-padding-remove-top">
                   <div className="uk-container uk-position-relative topheight" style={{ top: "0px" }}>
                        <div className="uk-text-left uk-margin-top uk-text-bold uk-margin-small-bottom" style={{ fontSize: "20px",color:'black' }}>IPLUS 360 Assests</div>
                                   <div className="release_title uk-text-left">{AssetsDetails.name_360}</div>
                                       <div className="uk-position-right uk-margin-top close">
                                             <a onClick={()=>history.push('/360_portal')}><span uk-icon="icon: close; ratio: 1.5"></span></a>
                                       </div>
                        </div>
                     <div className="uk-container uk-position-relative" style={{ top: "0px",height:'100vh' }}>
                     <div id="style-12" className="page_scroll" style={{overflowY:'scroll' }}>
                       <div class="uk-child-width-1-3@m uk-margin-top uk-grid-small uk-grid-match" uk-grid="">
                         {
                           AssetsDetails.assets_360 !== undefined && AssetsDetails.assets_360.length > 0 ? (
                           <>
                             {
                                 AssetsDetails.assets_360.map(function(item,index){
                                  return(
                                      <div key={index}>
                                         <div>
                                             {
                                               user_roles.games_createEdit==true||user_roles.games_super_admin == true || user_roles.games_remove ==true ? (
                                               <a className="uk-float-left" onClick={()=>edit_game(item,index)}>Edit</a>
                                               ):null 
                                             }
                                             <div className="clear"></div>
                                         <div class="uk-card uk-card-default uk-card-hover border_radius cardwidth elastic_card uk-margin-small-top">
                                             <div class="uk-card-header uk-padding-remove width100 border_radius cdpad">
                                           {
                                                 item.type=="360_Image" ? (
                                                 <div>
                                                     <Pannellum width="100%" height="240px" image={item.media} pitch={10} yaw={180} hfov={110}
                                                     autoLoad
                                                     showZoomCtrl={false}
                                                     onLoad={() => {console.log("panorama loaded");}}></Pannellum>
                                           </div>
                                          ):(
                                            <ReactPlayer  url={item.media} controls playing={autoplay}
                                            className="video_player"></ReactPlayer> 
                                          )
                                        }
                                 </div>
                                   <div class="uk-card-body uk-padding-small">
                                       <div>
                                            <div className="game_title">{item.name}</div>
                                       </div>
                                     <div className="uk-text-left description">{item.media_description}</div>
                                    <div >
                                      <div className="tag_video">
                                         <div className="durationcs">
                                            <div className="model_format_color tag uk-text-left ">
                                               {item.item_tags.length > 0 && item.item_tags[0]}
                                             </div>
                                         </div>
                                       <div className="model_formats">
                                            <div className="uk-text-right textclr">{item.type=="360_Image"?'Image':'Video' }</div>
                                       </div>
                                       </div>
                                       <div className="clear"></div>
                                    </div>
                                   </div>
                               </div>
                            </div>
                       </div>
                         )
                       })
                     }
                    </>
                  ):(
                  <div className="uk-position-center">
                     <div class="uk-alert-primary" uk-alert="">
                       <p>No 360 assets found!.</p>
                  </div>
                </div>
             )
          }
       </div>
    </div>
   </div>
              <div className="uk-container uk-position-relative uk-margin-top widthcontainer" style={{ top: "0px" }} >
                          <div className="page_footer">
                             <div className="bottom_div">
                                 <button className="filter-btn"></button>
                            </div>  
                            <div className="bottom_editPage">
                               {
                                user_roles.games_createEdit==true||user_roles.super_admin == true ? (
                                  <button className="create_btn" onClick={(e)=>create_games(e)}>+</button>
                                ):null
                               }
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
         <div id="create_games_model" style={{ display:'none',background: "#F2F2F2" }} className="modelscroll">
                 <div class="uk-width-1-2@m uk-flex uk-flex-center uk-container paddingRemove uk-margin-bottom">
                    <button class="uk-modal-close-full uk-close-large bgWhite uk-margin-right" type="button" uk-close="" onClick={()=>close_form()}></button>
                      <div uk-height-viewport=""></div>
                             <CreateForm label={buttonLabel} Update_games={updateGameFun} Create_games={createGameFun} assets360={assets360} setassets360={setassets360} delete360Object={delete360Object}/>
                 </div>
        </div>
    </div>
    )
}
