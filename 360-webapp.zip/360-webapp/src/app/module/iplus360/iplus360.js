import React,{useEffect,useState} from 'react';
import { userActions } from "../../../components/Login/loginAction";
import { useDispatch, useSelector } from "react-redux";
import './three_sixity.css';
//import noImage from "../../../static/images/noimage.png";
import moment from "moment";
import ModelIcon from "../../../static/images/3dModal-logo.png";
import user_image from "../../../static/images/user-img-1.png";
import {List_iplus360Actions,clonelistiplus360Request} from "../../../components/List  Iplus 360/list_360Action";
import {selectmodelResponse} from "../../../components/Selected 3D Model/selected_3dmodelAction";
import {listiplus360Response} from "../../../components/List  Iplus 360/list_360Action";
import { remove_iplus360Action ,removemodelResponse} from '../../../components/Remove 3D Model/remove_3dmodelAction';
import { Update_iplus360Actions,updatemodelResponse } from '../../../components/Update 3D Model/update_3dmodelAction';
import {Addnew_360AssetsActions,createmodelResponse} from "../../../components/Create 3D Model/create_3dModelAction";
//import {List_release_countActions} from "../../../components/List Release Status Count/list_release_status_countAction";
import {ListAll360AssetsActions} from "../../../components/List All 360Assets/list_all360ObjectsAction";
import {List_StatusActions} from "../../../components/List Status/list_statusAction";
import { Grid, Pagination } from 'semantic-ui-react';
import Create360coverForm from "./create_iplus360cover_form";
import '../../../static/css/semantic.css';
import UIkit from 'uikit';
import history from "../../../helpers/history";
export default function ThreeSixity(){

  const customerOrganisation = localStorage.getItem("organization")? localStorage.getItem("organization"): "";
  const user_roles = localStorage.getItem("user_roles") ? JSON.parse(localStorage.getItem("user_roles")) : "";

  const user_name = localStorage.getItem("username")? localStorage.getItem("username"): "";
  const [release_status, setrelease_status] = useState("live");

  useEffect(() => {
     dispatch(List_iplus360Actions.list_iplus360({page:"1",perPage:"3",status:"live"}))
     dispatch(List_StatusActions.read_status("geoblog_project_status"));
     dispatch(ListAll360AssetsActions.getall360objects());
    // dispatch(List_release_countActions.read_status_count());

    var getscreenheight = window.innerHeight;
    var topbar = document.getElementsByClassName('topheight')[0].offsetHeight;
    document.getElementsByClassName('verticalscroll')[0].style.height =  getscreenheight-topbar - 150 + 'px';
  }, [])

  const [search, setsearch] = useState('');
  const [selectedPage, setselectedPage] = useState(0);

  const [pagination, setpagination] = useState({
            activePage: 1,
            boundaryRange: 1,
            siblingRange: 1,
            showEllipsis: false,
            showFirstAndLastNav: true,
            showPreviousAndNextNav: true,
            textContent: 'Drop the items here !!',
       })

  const logout = useSelector(state => userActions.logout);
  const list360 = useSelector(state => state.list_360assets);
  const page_Details = list360.Asset360Data!==undefined ? list360.Asset360Data:{};
  const list360Res = list360.Asset360Data.docs!==undefined ? list360.Asset360Data.docs:[];
  const create_model = useSelector(state => state.create_threeDmodel);
  const create_modelRes = create_model.createmodelData!=undefined ? create_model.createmodelData:{};
  const updatemodelRes = useSelector(state => state.update_model);
  const updatemodel = updatemodelRes.updatedmodelData!=undefined ? updatemodelRes.updatedmodelData:{};
  const list_statusReducer = useSelector(state => state.list_statusReducer);
  const list_statusdata = list_statusReducer.statusData!==undefined ? list_statusReducer.statusData:[];
  const removeModel = useSelector(state => state.remove_Model);
  const removeModelRes = removeModel.removemodelData!=undefined ? removeModel.removemodelData:[];
  const release_count = useSelector(state => state.release_count);
  const releaseflagcount = release_count.release_status!==undefined ? release_count.release_status : {};

  const selectedthreedModel = useSelector(state => state.selected_model);
  const selectedthreedModelRes = selectedthreedModel.selectedmodelData!==undefined ? selectedthreedModel.selectedmodelData:{};

  const ReadAll360Assets = useSelector(state => state.ReadAll360Assets);
  const getall360Assets = ReadAll360Assets.all360objectsData!==undefined ?  ReadAll360Assets.all360objectsData:[];

  console.log('listModelsResponse-',list360Res);
 
  useEffect(() => {
    if(Object.keys(create_modelRes).length>0&&create_modelRes.status==0){
        UIkit.notification({message: create_modelRes.message, status: 'danger',timeout:'2000'});
     }
     else if(create_modelRes.status == 1){
      UIkit.notification({message: 'You have created IPLUS 360 Cover Successfully!', status: 'success',timeout:'2000'});
    }
    if(Object.keys(updatemodel).length>0&&updatemodel.status==0){
      UIkit.notification({message: updatemodel.message, status: 'danger',timeout:'2000'});
   }
   else if(updatemodel.status == 1){
      UIkit.notification({message: 'You have updated IPLUS 360 Cover Successfully!', status: 'success',timeout:'2000'});
  }
  if(Object.keys(removeModelRes).length>0&&removeModelRes.status==0){
    UIkit.notification({message: removeModelRes.message, status: 'danger',timeout:'2000'});
 }
 else if(removeModelRes.status == 1){
    UIkit.notification({message: 'You remove the IPLUS 360 Assets Successfully', status: 'success',timeout:'2000'});
}
}, [create_modelRes,updatemodel,removeModelRes])

const detailView=(item)=>{
  history.push(`/360_asset_details/${item.id_360}`)
}
const select_page = (e) =>{
   if(selectedPage!==0){
     dispatch(List_iplus360Actions.list_3dmodel({page:selectedPage,perPage:'3',status:release_status}))
       setpagination({...pagination,activePage:selectedPage})
   }
}
const handlePaginationChange = (e, { activePage }) =>{
  console.log("pagination--",activePage);
  if(release_status === "All"){
    setpagination({...pagination,activePage:activePage})
    dispatch(List_iplus360Actions.list_iplus360({page:activePage,perPage:'3'}))
  }
  else {
    setpagination({...pagination,activePage:activePage})
    dispatch(List_iplus360Actions.list_iplus360({page:activePage,perPage:'3',status:release_status}))
  }
}
const Filter_funct = (e) =>{
  document.getElementById('DownDiv').style.display = "block";
}
const closeFilter =(e) =>{
  document.getElementById('DownDiv').style.display = "none";
 }
const selectedFilter = (e,status) =>{
  if(status == "All"){
    setrelease_status(status);
    dispatch(List_iplus360Actions.list_iplus360({page:"1",perPage:'3'}))
    document.getElementById('DownDiv').style.display = "none";
  }
  else {
    setrelease_status(status);
    dispatch(List_iplus360Actions.list_iplus360({page:"1",perPage:'3',status:status}))
    document.getElementById('DownDiv').style.display = "none";
  }
}
const dateformat =(date)=>{
  var original_date = moment(date).format("YYYY-MM-DD");
   return original_date;
}
const create360cover =() =>{
  dispatch(selectmodelResponse({
    name_360:"",
    description_360:"",
    package_owner:"",
    package_writer:"",
    release_flag:"",
    search_tags:[],
    country_id:0,
   })
  )
   document.getElementById('list_card').style.display='none';
   document.getElementById('create_assets_model').style.display = "block";
}
const edit_360cover =(item)=>{
  dispatch(selectmodelResponse(item))
  document.getElementById('list_card').style.display='none';
  document.getElementById('create_assets_model').style.display = "block";
}
const close_formmodel = () =>{
  document.getElementById('list_card').style.display='block';
  document.getElementById('create_assets_model').style.display = "none";
}
const createiplus360cover =() =>{
  if(selectedthreedModelRes.name_360 == ''){
    UIkit.notification({message: 'Please enter the name of 360 cover!', status: 'success',timeout:'2000'});
   }
  else if(selectedthreedModelRes.description_360 == ''){
    UIkit.notification({message: 'Please enter the description of 360 cover!', status: 'success',timeout:'2000'});
  }
  else{
      //  update store
  var getstore = list360.Asset360Data.docs!==undefined ? list360.Asset360Data.docs:[];
  getstore.unshift(selectedthreedModelRes);
  dispatch(listiplus360Response({docs:getstore}))
  //API call
 dispatch(Addnew_360AssetsActions.add_new_iplus360(selectedthreedModelRes));
 setTimeout(() => {
     dispatch(createmodelResponse({}))
     dispatch(selectmodelResponse({
       name_360:"",
       description_360:"",
       package_owner:"",
       package_writer:"",
       release_flag:"",
       search_tags:[],
       country_id:0,
       })
     )
 }, 2000);
    document.getElementById('list_card').style.display="block";
    document.getElementById('create_assets_model').style.display="none";
  }
}
const updateiplus360cover = () =>{
 if(selectedthreedModelRes.id_360==0){
     UIkit.modal.alert("No model id is found!.Please referesh the page and try again.");
 }
 else{     
   var getstore = list360.Asset360Data.docs;
   getstore.length>0&&getstore.map((o)=>{
      if(o.id_360== selectedthreedModelRes.id_360){
         o.name_360 = selectedthreedModelRes.name_360
         o.description_360 = selectedthreedModelRes.description_360
         o.release_flag = selectedthreedModelRes.release_flag
      }
      return;
   })
  if(selectedthreedModelRes.release_flag == "dev" || selectedthreedModelRes.release_flag == "test" || selectedthreedModelRes.release_flag == "retired" ){
   const storeVal = getstore.filter(function( obj ) {
       return obj.id_360 !== selectedthreedModelRes.id_360
   });
        dispatch(listiplus360Response({...page_Details,docs:storeVal}));
   }
   else{
        dispatch(listiplus360Response({...page_Details,docs:getstore}))
   }
    document.getElementById('list_card').style.display="block";
    document.getElementById('create_assets_model').style.display="none";

    //API call
    dispatch(Update_iplus360Actions.edit_360assets(selectedthreedModelRes))
    setTimeout(() => {
     dispatch(updatemodelResponse({}))
  }, 2000);
}
}
const confirm360coverdelete =() =>{
    var getstore = list360.Asset360Data.docs;
    const storeVal = getstore.filter(function( obj ) {
        return obj.id_360 !== selectedthreedModelRes.id_360
    });

    dispatch(listiplus360Response({...page_Details,docs:storeVal}));
    //API call
    dispatch(remove_iplus360Action.delete_iplus360(selectedthreedModelRes.id_360))

    document.getElementById('list_card').style.display="block";
    document.getElementById('create_assets_model').style.display="none";   
    setTimeout(() => {
       dispatch(removemodelResponse({}))
    }, 2000);
}
const showlessbtn = (index) =>{
  document.getElementById('show_more_btn'+index).style.display = 'block';
  document.getElementById('toggle_para_show'+index).style.display = 'block';
  document.getElementById('toggle_para_hidden'+index).style.display = 'none';
  document.getElementById('show_less_btn'+index).style.display = 'none';
}
const showmorebtn = (index) =>{
  document.getElementById('show_more_btn'+index).style.display = 'none';
  document.getElementById('toggle_para_show'+index).style.display = 'none';
  document.getElementById('toggle_para_hidden'+index).style.display = 'block';
  document.getElementById('show_less_btn'+index).style.display = 'block';
}
const handleSearchinput = (e) =>{
  if(e.target.value!=""){
    const searchVal =  getall360Assets.length>0&&getall360Assets.filter((item) => {
     return item.name_360.toLowerCase().includes(e.target.value.toLowerCase()) ||
            item.search_tags.includes(e.target.value.toLowerCase())
      });  
       dispatch(clonelistiplus360Request({docs:searchVal}));
       setsearch(e.target.value);
     }
    else{
      dispatch(List_iplus360Actions.list_iplus360({page:"1",perPage:"3",status:"live"}))
      setsearch(e.target.value)
    }
}
const dispatch = useDispatch();
    return (
        <div>
         <div id="list_card" style={{display:'block'}}>
            <nav className="uk-navbar-container topheight" uk-navbar="" style={{ background: '#ffffff' }}>
              <div class="padc">
                 <div className="org_nav">{customerOrganisation}</div>
                   <img src={ModelIcon} alt="logo" className="aric"/>
            </div>
                <div className="uk-navbar-right">
                    <ul className="uk-navbar-nav uk-margin-right">
                        <li className="uk-active usr1">
                           <a>
                              <span className="uk-margin-small-right userImge">
                                   <img src={user_image} className="" />
                              </span>
                               <span className="usernamefont">{user_name}</span>
                          </a>
                          <div className="uk-navbar-dropdown customdropdown">
                                <ul className="uk-nav uk-navbar-dropdown-nav navfont">
                                    <li className="uk-flex-between uk-align-left">
                                    <a className="uk-float-left" onClick={()=>history.push('/change_password')}><span className="uk-margin-small-right" uk-icon="icon: unlock" ></span>
                                         <div className="uk-float-right">Change Password</div>
                                    </a>
                                    </li>
                                    <li className='uk-flex-between uk-align-left'>
                                        <a onClick={()=> dispatch(logout())}><span className="uk-margin-small-right" uk-icon="icon: sign-out" ></span>Sign-out</a>
                                    </li>
                                </ul>
                          </div>
                        </li>
                    </ul>
                </div>
            </nav>
              <div className="uk-text-center bgtheme">
                <div className="uk-width-expand@m">
                 <div className="uk-card  uk-card-body uk-padding-remove-bottom uk-padding-remove-top">
                      <div className="uk-container uk-position-relative widthcontainer" style={{ top: "0px" }}>
                        <div className="uk-search uk-search-default uk-align-center uk-margin-small-top uk-margin-small-bottom uk-background-muted uk-width-1-1@s searchwidth" >
                            <div className="uk-search-icon" uk-icon="search" />
                             <a class="uk-form-icon uk-form-icon-flip uk-close uk-icon" uk-close="" onClick={(e)=>{dispatch(List_iplus360Actions.list_3dmodel({page:"1",perPage:'3',status:release_status}));setsearch("")}}></a>
                             <input className="uk-search-input inputcls" type="search" placeholder="Search 360" style={{ borderRadius: "5px" ,backgroundColor:'#fff'}} value={search} onChange={(e)=>handleSearchinput(e)}/>
                        </div>
                     </div>
                   <div className="uk-section uk-section-large uk-flex uk-flex-center uk-padding-remove midsectionheight" style={{ height: "100vh" }}>
                     <div id="middle_section" className="uk-container uk-position-relative bodycontainer">
                       <div id="style-12" className="verticalscroll" style={{overflowY:'scroll' }}>
                         {
                        list360Res.length > 0 ? (
                          <div class="uk-child-width-1-3@m uk-grid-small uk-grid-match" uk-grid="">
                              {list360Res.map(function(item,index){
                              return(
                               <div key={index}>
                                 <div>
                                 {
                                  user_roles.games_createEdit==true||user_roles.games_super_admin == true || user_roles.games_remove ==true ? (
                                        <a className="uk-float-left" onClick={()=>edit_360cover(item)}>Edit</a>
                                        ):null 
                                    }
                                  <div className="clear"></div>
                                  <div class="uk-card uk-card-default uk-card-hover border_radius cardwidth elastic_card uk-margin-small-top">
                                    <div class="uk-card-body uk-padding-small">
                                        <div>
                                             <div className="game_title">{item.name_360}</div>
                                        </div>
                                     <div>
                                       {
                                         item.description_360 && item.description_360.length >120 ?(
                                          <>
                                            <div className="show_more_dis" id={"toggle_para_show"+index}>
                                               {item.description_360.substring(0,140)}<span>..</span>
                                              <a id={"show_more_btn"+ index} className="uk-float-right showbtn" onClick={()=>showmorebtn(index)}>Show more</a>
                                          </div>
                                          <div className="show_more_dis" id={"toggle_para_hidden"+index} style={{display:'none'}}>
                                            {item.description_360}
                                            <a id={"show_less_btn"+ index} className="uk-float-right showbtn" onClick={()=>showlessbtn(index)}>Show less</a>
                                          </div>
                                           <div className="clearfix"></div>
                                           </>
                                         ):(
                                           <>
                                            {item.description_360}
                                           </>
                                         )
                                       }
                                   </div>
                                     <div className="uk-margin-small-top">
                                          <div className="durationcs">
                                             <div className="model_format_color uk-text-left">
                                                {item.updated!==undefined ? dateformat(item.updated) :  dateformat(Date.now())}
                                              </div>
                                          </div>
                                        <div className="model_formats">
                                             <div className="uk-text-right textclr">{item.assets_360!==undefined ? item.assets_360.length:0} ASSETS</div>
                                        </div>
                                        <div className="clear"></div>
                                     </div>
                                    </div>
                                   <div class="uk-card-footer uk-text-center uk-padding-remove footer_rad">
                                       <div className="footerpad">
                                              <div className="buycs cdpad" onClick={()=>detailView(item)}>VIEW</div>
                                      </div>
                                        <div className="customfoot">
                                             <div className="buycs fonsize">Customization Request</div>
                                        </div>
                                  </div>
                               </div>
                             </div>
                           </div>
                         )
                       }
                       )}
                  </div>
                             ):(
                              <div className="uk-position-center">
                                  <div class="uk-alert-primary" uk-alert="">
                                    <p>No 360 assets found!.</p>
                                  </div>
                               </div>
                             )
                     }
           </div>
            </div>
                 </div>
                       <div className="uk-container uk-position-relative uk-margin-top widthcontainer" style={{ top: "0px" }} >
                         <div className="page_footer">
                             <div className="bottom_div">
                                 <button className="filter-btn" onClick={()=>Filter_funct()}></button>
                            </div>  
                            <div className="middlecl">
                              <Grid columns={1}>
                                        <Grid.Column>
                                          <Pagination
                                                activePage={pagination.activePage}
                                                boundaryRange={pagination.boundaryRange}
                                                onPageChange={handlePaginationChange}
                                                size='mini'
                                                siblingRange={pagination.siblingRange}
                                                totalPages={page_Details.totalPages}
                                                ellipsisItem={pagination.showEllipsis ? undefined : null}
                                                firstItem={pagination.showFirstAndLastNav ? undefined : null}
                                                lastItem={pagination.showFirstAndLastNav ? undefined : null}
                                                prevItem={pagination.showPreviousAndNextNav ? undefined : null}
                                                nextItem={pagination.showPreviousAndNextNav ? undefined : null}
                                            />
                                         </Grid.Column>
                                    </Grid>
                            </div>   
                              <div className="searchdiv">
                                   <div className="outerdiv">
                                       <div className="inputdiv">
                                         <input class="uk-input brd_rad" type="number" value={selectedPage} onChange={(e)=>setselectedPage(e.target.value)} /></div>
                                       <div className="btndiv"><button className="uk-button go_btn" onClick={(e)=>select_page(e)}>Go</button></div>
                                   </div>    
                              </div>
                              <div className="bottom_editPage">
                               {
                                user_roles.games_createEdit==true||user_roles.super_admin == true ? (
                                  <button className="create_btn" onClick={()=>create360cover()}>+</button>
                                ):null
                               }
                            </div>                      
                        </div>
                       <div id="DownDiv" className="uk-card uk-card-default uk-card-body uk-animation-slide-bottom uk-position-left-center bottomStyle" style={{display:'none'}}>
                          <p className="uk-text-bold uk-position-top-center uk-padding" style={{ color: "black", fontSize: "15px" }}>Filters</p>
                            <div className="uk-position-right">
                         <div className="uk-padding uk-text-bold" style={{ color: "rgb(0, 172, 193)", cursor: "pointer" }} onClick={()=>closeFilter()}>Close</div>
                       </div><br />
                      <ul className="uk-list uk-list-divider">
                      {
                      list_statusdata.length>0&&list_statusdata.map(function(item){
                       if(item.name == "live"){
                            return(
                            <li id="createclick" style={{ cursor: "pointer" ,textTransform:'capitalize'}}  onClick={(e)=>selectedFilter(e,item.name)}><span className="uk-float-left">{item.name}</span> <span className="uk-float-right">{releaseflagcount.release_flag_live}</span> </li>
                              )
                         }
                          else if(item.name == "test"){
                             return(
                             <li id="createclick" style={{ cursor: "pointer",textTransform:'capitalize' }}  onClick={(e)=>selectedFilter(e,item.name)}><span className="uk-float-left">{item.name}</span> <span className="uk-float-right">{releaseflagcount.release_flag_test}</span> </li>
                             )
                           }
                           else if(item.name == "dev"){
                            return(
                              <li id="createclick" style={{ cursor: "pointer",textTransform:'capitalize' }}  onClick={(e)=>selectedFilter(e,item.name)}><span className="uk-float-left">{item.name}</span> <span className="uk-float-right">{releaseflagcount.release_flag_dev}</span> </li>
                            )
                           }
                           else if(item.name == "retired"){
                            return(
                              <li id="createclick" style={{ cursor: "pointer",textTransform:'capitalize' }}  onClick={(e)=>selectedFilter(e,item.name)}><span className="uk-float-left">{item.name}</span> <span className="uk-float-right">{releaseflagcount.release_flag_retired}</span> </li>
                            )
                           }
                         })
                         }
                         <li id="createclick" style={{ cursor: "pointer" }}  onClick={(e)=>selectedFilter(e,"All")}><span className="uk-float-left">All</span> <span className="uk-float-right">{releaseflagcount.list_all_records}</span> </li>
                          </ul>
                        </div>
                     </div>
                  </div>
                </div>
              </div>
           </div>
          <div>
       </div>
      <div id="create_assets_model" style={{display:'none',background: "#F2F2F2" }} className="modelscroll">
                 <div class="uk-width-1-2@m uk-flex uk-flex-center uk-container paddingRemove uk-margin-bottom">
                    <button class="uk-modal-close-full uk-close-large bgWhite uk-margin-right" type="button" uk-close="" onClick={()=>close_formmodel()}></button>
                      <div uk-height-viewport=""></div>
                        <Create360coverForm updateiplus360cover={updateiplus360cover} createiplus360cover={createiplus360cover} confirm360coverdelete={confirm360coverdelete}/>
                 </div>
        </div>
  </div>
    )
}
