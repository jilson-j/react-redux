import React,{useState} from 'react'
import {useSelector } from "react-redux";
import './three_sixity.css';
import ReactPlayer from "react-player";
import{userConstants} from '../../../constants/user.constants'
import closeicon from "../../../static/images/close_icon.png";
import tag from  "../../../static/images/tags.svg";
import "react-image-crop/dist/ReactCrop.css";
import UIkit from 'uikit';
export default function CreateForm({label,Create_games,Update_games,assets360,setassets360,delete360Object}) {

  const token = localStorage.getItem("token") ? localStorage.getItem("token") : "";
  const user_roles = localStorage.getItem("user_roles") ? JSON.parse(localStorage.getItem("user_roles")) : "";
     const [uploadImagefile, setuploadImagefile] = useState();
     const [uploadVideofile, setuploadVideofile] = useState();
     const [progressValue, setprogressValue] = useState(0)
     const [itemtags, setitemtags] = useState()
     //Get from store
     
     const GetSelected360Assets = useSelector(state => state.GetSelected360Assets);
     const AssetsDetails = GetSelected360Assets.selectedAsset360!==undefined ? GetSelected360Assets.selectedAsset360 :{}

     const dragImagefile =(e) =>{
        UIkit.upload("#uploaddiv .js-upload", {
            url: "",
            multiple: true,
            beforeSend: function () {
              console.log("beforeSend", arguments);
            },
            beforeAll: function () {
             if (arguments[1][0].type == "image/png" || arguments[1][0].type == "image/jpeg") {
                var local_file = URL.createObjectURL(arguments[1][0]);
                setuploadImagefile(arguments[1][0]);
                let getitem = {...assets360}
                getitem.media = local_file
                setassets360(getitem)
                document.getElementById("upload_status_failure").style.display = "block";
              } else {
                UIkit.modal.alert( "File must be a .jpg or .png!");
              }
            }
          });
     }
     const uploadImageS3 = async(e) =>{
      if (uploadImagefile === "") {
        document.getElementById('upload_status_error').style.display ="block";
        setTimeout(() => {
          document.getElementById('upload_status_error').style.display ="none";
        }, 2000);
        }
        else{

          var newFileName = Date.now() + "_" + uploadImagefile.name.split(".")[0].replace(/\s+/g, "-");
        //   AWS.config.update({
        //     signatureVersion: "v4",
        //     region:  config.region,
        //     accessKeyId: config.accessKeyId,
        //     secretAccessKey: config.secretAccessKey,
        //   });
        //    var bucket = new AWS.S3({
        //     params: { Bucket: config.bucketName},
        //     region: config.region,
        //   })
        //   const params = {
        //     ACL: 'public-read',
        //     Key: `assets_360/${newFileName}`,
        //     ContentType: uploadImagefile.type,
        //     Body: uploadImagefile,
        //   }
        //   bucket.upload(params).on('httpUploadProgress', function(evt) {
        //     var uploaded = Math.round(evt.loaded / evt.total * 100);
        //     console.log(`File uploaded: ${uploaded}%`);
        //     setprogressValue(Math.round((evt.loaded / evt.total) * 100))
        //     document.getElementById('js-progressbar').style.display = "block";
        //     if(uploaded === 100){
        //       setTimeout(() => {
        //        setprogressValue(0)
        //        document.getElementById('js-progressbar').style.display = "none";
        //       }, 2000);
        //    }
        // }).send(function(err, data) {
        //     if (err){
        //         // an error occurred, handle the error
        //         console.log(err, err.stack);
        //         return;
        //     }
        //     console.log('File URL:', data.Location);
        //     setassets360({...assets360,media:data.Location})
        //     setuploadImagefile("");
        //     document.getElementById("upload_status_success").style.display ="block";
        //     document.getElementById("upload_status_failure").style.display ="none";
        //     setTimeout(() => {
        //        document.getElementById("upload_status_success").style.display ="none";
        //   }, 2000); 
        //    // alert('File is uploaded successfully!');
        // })  
        var folder_name = "IPLUS_360"
                  let formData = new FormData();
                  formData.append("folder_name",folder_name)
                  formData.append('images', uploadImagefile)
                  try {
                  const response = await fetch(userConstants.FILE_UPLOAD, {
                  method: 'POST',
                  headers:{
                  'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
                  'token-key': token
                  },
                  body: formData
                  })
                  // Use the `.json` method on the fetch response object
                  var response_data = await response.json();
                  console.log('data', response_data);
                  if(response_data.status == 1 && response_data.data.length>0){
                    console.log('File URL:', response_data.data[0]);
                    setassets360({...assets360,media:response_data.data[0]})
                    setuploadImagefile("");
                    document.getElementById("upload_status_success").style.display ="block";
                    document.getElementById("upload_status_failure").style.display ="none";
                    setTimeout(() => {
                      document.getElementById("upload_status_success").style.display ="none";
                    }, 2000); 
                  }
                  else if(response_data.status == 0){
                  alert(response_data.message)
                  }
                  else {
                  alert("file not uploaded correctly")
                  }
                  }
                  catch (error) {
                  alert("error",error)
                  }  
      }
     }
     const dragvideofile =() =>{
      UIkit.upload("#image_uploaddiv  .js-upload", {
          url: "",
          multiple: true,
          beforeSend: function () {
            console.log("beforeSend", arguments);
          },
          beforeAll: function () {
           if (arguments[1][0].type == "video/mp4") {
             var local_file = URL.createObjectURL(arguments[1][0]);
              setuploadVideofile(arguments[1][0]);
               setassets360({...assets360,media:local_file})
              document.getElementById("upload_video_failure").style.display = "block";
            } else {
              UIkit.modal.alert( "File must be a .mp4!");
            }
          },
        });
     }
     const uploadVideoS3 = async(index) =>{
      if(uploadVideofile===""){
        document.getElementById('upload_video_error'+index).style.display ="block";
        setTimeout(() => {
            document.getElementById('upload_video_error'+index).style.display ="none";
        }, 2000);
      }
      else{
        var newFileName = Date.now() + "_" + uploadVideofile.name.split(".")[0].replace(/\s+/g, "-");
      //   AWS.config.update({
      //     signatureVersion: "v4",
      //     region:  config.region,
      //     accessKeyId: config.accessKeyId,
      //     secretAccessKey: config.secretAccessKey,
      //   });
      //    var bucket = new AWS.S3({
      //     params: { Bucket: config.bucketName},
      //     region: config.region,
      //   })
      //   const params = {
      //     ACL: 'public-read',
      //     Key: `assets_360/${newFileName}`,
      //     ContentType: uploadVideofile.type,
      //     Body: uploadVideofile,
      //   }
      //   bucket.upload(params).on('httpUploadProgress', function(evt) {
      //     var uploaded = Math.round(evt.loaded / evt.total * 100);
      //     console.log(`File uploaded: ${uploaded}%`);
      //     setprogressValue(Math.round((evt.loaded / evt.total) * 100))
      //     document.getElementById('js-progressbar').style.display = "block";
      //     if(uploaded === 100){
      //       setTimeout(() => {
      //        setprogressValue(0)
      //        document.getElementById('js-progressbar').style.display = "none";
      //       }, 2000);
      //    }
      // }).send(function(err, data) {
      //     if (err){
      //         // an error occurred, handle the error
      //         console.log(err, err.stack);
      //         return;
      //     }
      //     console.log('File URL:', data.Location);
      //     setassets360({...assets360,media:data.Location})
      //     document.getElementById('upload_video_failure').style.display = "none"
      //     document.getElementById("upload_video_success").style.display ="block";
      //     setuploadVideofile("");
      //     setTimeout(() => {
      //       document.getElementById("upload_video_success").style.display ="none";
      //      }, 2000); 
      // })  
      
      var folder_name = "IPLUS_360"
      let formData = new FormData();
      formData.append("folder_name",folder_name)
      formData.append('images', uploadVideofile)
      try {
      const response = await fetch(userConstants.FILE_UPLOAD, {
      method: 'POST',
      headers:{
      'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ=',
      'token-key': token
      },
      body: formData
      })
      // Use the `.json` method on the fetch response object
      var response_data = await response.json();
      console.log('data', response_data);
      if(response_data.status == 1 && response_data.data.length>0){
        console.log('File URL:', response_data.data[0]);
        setassets360({...assets360,media:response_data.data[0]})
        document.getElementById('upload_video_failure').style.display = "none"
        document.getElementById("upload_video_success").style.display ="block";
        setuploadVideofile("");
        setTimeout(() => {
        document.getElementById("upload_video_success").style.display ="none";
        }, 2000); 
      }
      else if(response_data.status == 0){
      alert(response_data.message)
      }
      else {
      alert("file not uploaded correctly")
      }
      }
      catch (error) {
      alert("error",error)
      }   


    }
      }
     const remove_games = (e) =>{
        UIkit.modal("#confirm_delete").show();
     } 
     const add_item_tags = () =>{
       if(itemtags == ''){

        }
       else{
        let getItem = assets360.item_tags
        getItem.push(itemtags);
        setassets360({...assets360,item_tags:getItem})
        setitemtags('')
       }
     }
     const remove_item_tags =(indx) =>{
      let getItem = assets360.item_tags
      getItem.splice(indx,1);
      setassets360({...assets360,item_tags:getItem})
      setitemtags('')
     }
     console.log("assets",assets360);
    return (
         <div className="uk-width-1-1 width80 createsubscription">
             <div className="uk-card uk-card-body uk-padding-remove">
                <div className="uk-container uk-position-relative topbar" style={{ top: "0px" }}>
                    <div className="uk-text-left uk-text-bold uk-margin-top Textcolor" style={{ fontSize: "22px" }}>{label == "Create" ? 'Create 360 Assets ':'Update 360 Assets '}</div>
                        <div className="uk-text-left uk-margin-small-top" style={{color:'gray'}}>{AssetsDetails.name_360}</div>
                </div>
            </div>
          <div className="uk-margin-small-top">
            <div className="uk-margin">
             <label className="Textcolor">Media Type</label> 
             <div className="uk-margin">
               <select name="type" class="uk-select" id="form-stacked-select" value={assets360.type} onChange={(e)=>setassets360({...assets360,type:e.target.value})}>
                 <option value="0" >--Select--</option>
                 <option value="360_Image" selected>360 Image</option>
                 <option value="360_Video" >360 Video</option>
               </select>
               </div>
             </div>
             <label className="Textcolor">Name</label>
             <div className="uk-margin">
                 <input type="text" class="uk-textarea" name="name" rows="3" placeholder="Name" value={assets360.name} onChange={(e)=>setassets360({...assets360,name:e.target.value})}/>
             </div>
               {
                 assets360.type =='360_Image'?(
                  <div className="image_model">
                  <label className="Textcolor">Image 360</label>
                 {
                  assets360.media!=="" &&  assets360.media!==undefined && (
                  <div className="imageinner uk-margin-top">
                       <div className="closediv">
                           <a onClick={()=>setassets360({...assets360,media:""})}>
                              <img src={closeicon} className="image_preview" alt="close"/>
                           </a>
                           <img src={assets360.media} alt="image" className="gameImage"/>
                         </div>
                         <div className="clear"></div>
                     </div>
                   )
                 }
                 <div id="uploaddiv" onDragEnter={(e) =>dragImagefile(e)} >
     ​               <div class="js-upload uk-placeholder uk-text-center outline custom_placeholder">
                       <label for="file-input"> 
                         <div class="uk-text-middle"> Drag and drop your jpeg or png images or <span className="hastags">browse</span>
                         <progress id="js-progressbar" class="uk-progress" value={progressValue} max="100" style={{display:'none'}}></progress>                   
                             <div id="upload_status_success" class="uk-alert-success" style={{display: "none"}} uk-alert="">
                                    <div>Image Uploaded Successfully</div>
                                </div>
                               <div id="upload_status_failure" style={{display: "none"}} class="uk-alert-primary alert_height" uk-alert="">
                                     <div>Please click upload button before saving this form</div>
                               </div>
                               <div id="upload_status_error" style={{display: "none"}} class="uk-alert-danger alert_height" uk-alert="">
                                    <div>No Images selected to upload!.</div>
                            </div>
                         </div>
                       </label>
                        <div className="custominput" uk-form-custom="true" onClick={(e)=>dragImagefile(e)}>
                            <input id="file-input" type="file" />
                       </div>
                         <button class={"uk-button uk-button-small "+(assets360.media.includes('https://smitiv-s3-storage.s3') ? 'upload-disabled':'upload-btn') } disabled={assets360.media.includes('https://smitiv-s3-storage.s3') ? true : false} onClick={(e)=>uploadImageS3(e)}>
                             <span uk-icon="upload"></span>Upload
                         </button>
                    </div>
                 </div>
                 </div>
                 ):(
                <div id="video_model">
                  <label className="Textcolor">Video 360</label>
                    {
                          assets360.media!== "" && (
                           <div className="imageinner uk-margin-top">
                              <div className="closediv">
                                 <a onClick={()=> setassets360({...assets360,media:""})}>
                                    <img src={closeicon} className="image_preview" alt="close"/>
                                 </a>
                                 <ReactPlayer className="vedio_css" url={assets360.media}></ReactPlayer>
                             </div>
                             <div className="clear"></div>
                          </div>
                        )
                   }
                 <div id="image_uploaddiv" onDragEnter={() =>dragvideofile()}>
      ​             <div class="js-upload uk-placeholder uk-text-center outline custom_placeholder">
                        <label htmlFor="file-input"> 
                          <div class="uk-text-middle"> Drag and drop your video files mp4 or <span className="hastags">browse</span>
                          <progress id={"js-progressbar"} class="uk-progress" value={progressValue} max="100" style={{display:'none'}}></progress> 
                              <div id="upload_video_success" class="uk-alert-success" style={{display: "none"}} uk-alert="">
                                     <div>Video uploaded Successfully</div>
                                 </div>
                                <div id="upload_video_failure" style={{display: "none"}} class="uk-alert-primary alert_height" uk-alert="">
                                      <div>Please click upload button before saving this form</div>
                                </div>
                                <div id="upload_video_error" style={{display: "none"}} class="uk-alert-danger alert_height" uk-alert="">
                                      <div>No Video file is selected to upload!.</div>
                             </div>
                          </div>
                        </label>
                         <div className="custominput" uk-form-custom="true" onClick={()=>dragvideofile()}>
                             <input id="file-input" type="file" />
                        </div>
                          <button class={"uk-button uk-button-small "+(assets360.media.includes('https://smitiv-s3-storage.s3') ? 'upload-disabled':'upload-btn') } disabled={assets360.media.includes('https://smitiv-s3-storage.s3') ? true : false} onClick={()=>uploadVideoS3()}>
                              <span uk-icon="upload"></span>Upload
                          </button>
                     </div>
                  </div>
               </div>
                 )
               }
               <label className="Textcolor">Media Description</label>
                   <div className="uk-margin">
                     <textarea class="uk-textarea" rows="3" name="media_description" placeholder="Media description" value={assets360.media_description} onChange={(e)=>setassets360({...assets360,media_description:e.target.value})}></textarea>
                  </div>
               <label className="Textcolor">Tag</label>
                  <div className="uk-margin">
                        <div class="uk-inline uk-width-1-1">
                             <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: plus" onClick={()=>add_item_tags()}></a>
                             <input type="text" class="uk-textarea" name="tag"  rows="3" placeholder="Tag" value={itemtags} onChange={(e)=>setitemtags(e.target.value)}/>
                        </div>
                   </div>
                   {
                     assets360.item_tags.length > 0 && assets360.item_tags.map(function(item,index){
                        return(
                       <div className="searchtags">
                          <img src={tag} className="tags_cls"/><span className="hastags">{item}</span>
                          <a><img src={closeicon} className="close_searchtag" alt="close" onClick={()=>remove_item_tags(index)} /></a>
                        </div>
                        )
                     })
                   }
             </div>
         <div className="uk-text-center uk-margin">
                    {
                        label == "Create" ? (
                            <button className="uk-button check_btn" onClick={(e)=>Create_games(e)}>CREATE</button>
                        ):(
                          <div>
                               <button className="uk-button check_btn" onClick={(e)=>Update_games(e)}><span className="edit_iconcls" uk-icon="icon:  file-edit"></span>UPDATE</button><br />
                                  {
                                   user_roles.games_remove==true || user_roles.games_super_admin == true  ? 
                                      ( 
                                     <button class="uk-button deletebtn uk-margin-top" type="button" onClick={(e)=>remove_games(e)}><span className="edit_iconcls" uk-icon="icon:  trash"></span>Delete</button>
                                 ):null}
                          </div>
                        )
                    }
              </div>
          <div id="confirm_delete" class="uk-flex-top" uk-modal="">
              <div class="uk-modal-dialog custom_radius uk-modal-body uk-margin-auto-vertical">
                <button class="uk-modal-close-default" type="button" uk-close=""></button>
                     <p>Are you sure you want to delete this items ?</p>
                  <div className="uk-float-right">
                     <button class="uk-button uk-button-default uk-modal-close uk-margin-right custom_confirm_btn" type="button">Cancel</button>
                     <button class="uk-button uk-button-danger uk-modal-close custom_confirm_btn" type="button" onClick={()=>delete360Object()}>Confirm</button>
                  </div>
           </div>
         </div>
        </div>
    )
}
