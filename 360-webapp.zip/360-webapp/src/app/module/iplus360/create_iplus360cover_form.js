import React,{useState} from 'react'
import {useSelector,useDispatch } from "react-redux";
import closeicon from "../../../static/images/close_icon.png";
import tag from  "../../../static/images/tags.svg";
import {selectmodelResponse} from "../../../components/Selected 3D Model/selected_3dmodelAction";
import UIkit from 'uikit';
export default function Create360coverForm({createiplus360cover,updateiplus360cover,confirm360coverdelete}) {

    const customerOrganisation = localStorage.getItem("organization")? localStorage.getItem("organization"): "";
    const user_roles = localStorage.getItem("user_roles") ? JSON.parse(localStorage.getItem("user_roles")) : "";
     
    const [searchtag, setsearchtag] = useState("");
    const list_statusReducer = useSelector(state => state.list_statusReducer);
    const list_statusdata = list_statusReducer.statusData!==undefined ? list_statusReducer.statusData:[];
    const selectedthreedModel = useSelector(state => state.selected_model);
    const selectedthreedModelRes = selectedthreedModel.selectedmodelData!==undefined ? selectedthreedModel.selectedmodelData:{};
  
    const removeiplus360cover = () =>{
        UIkit.modal("#confirm_delete_360cover").show();
    }
    const Add_searchTag =() =>{
        if(searchtag == ""){
        }
        else{
           let getItem  = selectedthreedModel.selectedmodelData;
           getItem.search_tags.push(searchtag);
           dispatch(selectmodelResponse(getItem))
           setsearchtag("");
         }
       }
       const remove_tags = (indx) =>{
        let getItem  = selectedthreedModel.selectedmodelData;
        getItem.search_tags.splice(indx,1)
        dispatch(selectmodelResponse(getItem))
       }
    const dispatch = useDispatch();
    return (
        <div className="uk-width-1-1 width80 createsubscription">
            <div className="uk-card uk-card-body uk-padding-remove">
                <div className="uk-container uk-position-relative topbar" style={{ top: "0px" }}>
                    <div className="uk-text-left uk-text-bold uk-margin-top Textcolor" style={{ fontSize: "22px" }}>Create 360 Cover</div>
                        <div className="uk-text-left uk-margin-small-top" style={{color:'gray'}}>{customerOrganisation}</div>
                </div>
            </div>
            <div>
                <div className="Textcolor uk-margin-top">360 Name</div>
                <div className="uk-margin">
                    <input className="uk-input textbox_create" name="name_360" type="text" placeholder="360 name" value={selectedthreedModelRes.name_360} onChange={(e)=>dispatch(selectmodelResponse({...selectedthreedModelRes,name_360:e.target.value}))} />
                </div>
                <div className="clear" />
            </div>
            <label className="Textcolor">360 Description</label>
             <div className="uk-margin">
                 <textarea class="uk-textarea" name="description_360"rows="3" placeholder="360 description" value={selectedthreedModelRes.description_360} onChange={(e)=>dispatch(selectmodelResponse({...selectedthreedModelRes,description_360:e.target.value}))}></textarea>
             </div>
         <label className="Textcolor">Search Tags</label> 
                    <div className="uk-margin">
                        <div class="uk-inline uk-width-1-1">
                             <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: plus" onClick={()=>Add_searchTag()}></a>
                             <input className="uk-input textbox_create" type="text" placeholder="Search tag" value={searchtag} onChange={(e)=>setsearchtag(e.target.value)}/>
                        </div>
                   </div>
                   {
                     selectedthreedModelRes.search_tags.length > 0 && selectedthreedModelRes.search_tags.map(function(item,index){
                        return(
                       <div className="searchtags">
                          <img src={tag} className="tags_cls"/><span className="hastags">{item}</span>
                          <a><img src={closeicon} className="close_searchtag" alt="close" onClick={()=>remove_tags(index)} /></a>
                        </div>
                        )
                     })
                   }
            <div>
             <label className="Textcolor">Release</label> 
                   <div className="uk-margin">
                         <select class="uk-select" id="form-stacked-select" name="release_flag" value={selectedthreedModelRes.release_flag} onChange={(e)=>dispatch(selectmodelResponse({...selectedthreedModelRes,release_flag:e.target.value}))}>
                           <option value="">Select release type</option>
                           {
                             list_statusdata.length>0&&list_statusdata.map(function(item){
                               return(
                                   <option value={item.name} selected={item.name == selectedthreedModelRes.release_flag}>{item.name}</option>
                                )
                             })
                           }
                      </select>
                </div>
             </div>
                <div className="uk-text-center uk-margin">
                {
                        selectedthreedModelRes.id_360 == undefined ? (
                            <button className="uk-button check_btn" onClick={()=>createiplus360cover()}>CREATE</button>
                        ):(
                          <div>
                               <button className="uk-button check_btn" onClick={()=>updateiplus360cover()}><span className="edit_iconcls" uk-icon="icon:  file-edit"></span>UPDATE</button><br />
                                  {
                                   user_roles.games_remove==true || user_roles.games_super_admin == true  ? 
                                      ( 
                                     <button class="uk-button deletebtn uk-margin-top" type="button" onClick={()=>removeiplus360cover()}><span className="edit_iconcls" uk-icon="icon:  trash"></span>Delete</button>
                                 ):null}
                          </div>
                        )
                    }
              </div>
            <div id="confirm_delete_360cover" class="uk-flex-top" uk-modal="">
              <div class="uk-modal-dialog custom_radius uk-modal-body uk-margin-auto-vertical">
                <button class="uk-modal-close-default" type="button" uk-close=""></button>
                     <p>Are you sure you want to delete this items ?</p>
                  <div className="uk-float-right">
                     <button class="uk-button uk-button-default uk-modal-close uk-margin-right custom_confirm_btn" type="button">Cancel</button>
                     <button class="uk-button uk-button-danger uk-modal-close custom_confirm_btn" type="button" onClick={(e)=>confirm360coverdelete(e)}>Confirm</button>
                  </div>
           </div>
         </div>
        </div>
    )
}
