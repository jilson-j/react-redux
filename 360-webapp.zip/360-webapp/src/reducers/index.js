import { combineReducers } from "redux";
import {registeration} from "../components/Register/registerReducer";
import { authentication } from "../components/Login/loginReducer";
import { userEmail } from "../components/Login/userEmailReducer";
import {forgotPassword} from "../components/Forgot Password/forgotPasswordReducer";
import {changePassword} from "../components/Change Password/changePasswordReducer";
import {list_iplus360model} from "../components/List  Iplus 360/list_360Reducer";
import {selectedModelDetails} from "../components/Selected 3D Model/selected_3dmodelReducer";
import {createmodel} from "../components/Create 3D Model/create_3dModelReducer";
import {updateModel} from "../components/Update 3D Model/update_3dmodelReducer";
import {list_status} from "../components/List Status/list_statusReducer";
import {removeModel} from "../components/Remove 3D Model/remove_3dmodelReducer";
import {list_formats} from "../components/List Model Formats/list_modelformatsReducer";
import {list_status_count} from "../components/List Release Status Count/list_release_status_countReducer";
import {getall360Assets} from "../components/List All 360Assets/list_all360ObjectsReducer";
import {select_list_iplus360} from "../components/Get Selected Assets360/get_asssets360Reducer";
import {createAssets360} from "../components/Create 360Assets/create_360assetsReducer";
import {update360Object} from "../components/Update Assets360/update_assetsReducer";
import {delete360Object} from "../components/Remove Assets360/remove_assets360Reducer";
const allReducer = combineReducers({
  registerReducer:registeration,
  userEmailReducer: userEmail,
  loginReducer: authentication,
  logoutReducer: authentication,
  forgotPasswordReducer:forgotPassword,
  changePasswordReducer:changePassword,
  list_360assets:list_iplus360model,
  selected_model:selectedModelDetails,
  create_threeDmodel:createmodel,
  update_model:updateModel,
  list_statusReducer:list_status,
  remove_Model:removeModel,
  modelformats:list_formats,
  release_count:list_status_count,
  ReadAll360Assets:getall360Assets,
  GetSelected360Assets:select_list_iplus360,
  Create360Object: createAssets360,
  Update360AssetObject : update360Object,
  Remove360Object : delete360Object,
});
export default allReducer;
